# SignalIQ

**Find the signal. Fix the problem.**  
Customer Feedback Intelligence & Decision Platform

SignalIQ helps businesses convert customer feedback from reviews, surveys, and support conversations into evidence-backed insights, explainable priorities, tracked actions, and useful reports.

> **Reconstruction status:** This repository currently contains an early single-user prototype. The documents in `docs/` describe the intended rebuilt product. Features documented as target requirements must not be assumed to exist until implemented and verified.

## Product workflow

**Collect → Analyze → Discover → Prioritize → Act → Report**

1. Collect feedback through manual entry and validated CSV import.
2. Analyze comments for sentiment, topics, issue categories, severity, and evidence-grounded explanations.
3. Discover repeated and emerging customer problems.
4. Prioritize issues using documented, explainable scoring.
5. Track actions and resolution status.
6. Export a report that reflects the selected, current dataset.

Gemini supports the current AI-analysis workflow. Adaption Adaptive Data is a separate workflow for preparing and optimizing reviewed training examples; its output is not the live classifier.

## Canonical documentation

Read `AGENTS.md` first when using a coding agent, then:

- `docs/CURRENT_STATE_AUDIT.md` — known current state and unknowns.
- `docs/PRD.md` — product scope and acceptance criteria.
- `docs/DEVELOPMENT_PHASES.md` — phase order and gates.
- `docs/UX_DESIGN_SPEC.md` and `docs/DESIGN_SYSTEM.md` — experience and visual direction.
- `docs/DECISIONS.md` — decisions the agent must not casually reverse.
- `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md` — target technical design.
- `docs/AI_AND_ADAPTION.md` — AI and Adaptive Data behavior.
- `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md` — quality and release requirements.
- `docs/PHASE_EXECUTION_TEMPLATE.md` — structure for future phase prompts.

These documents supersede old contradictory prompts and copied documentation bundles.

## Current repository baseline

The existing repository uses:

- Frontend: React, TypeScript, Vite, Tailwind CSS, React Router, Recharts, Lucide.
- Backend: Python, FastAPI, Pydantic.
- Current AI provider integration: Google Gemini, called server-side.
- Adaptive Data integration path: Adaption Python SDK.
- Tests: Vitest, React Testing Library, pytest.

The current prototype stores feedback and issue state in browser `localStorage`. The backend has no primary feedback database, authentication is not implemented, and Adaption job metadata is held in memory. Those are known gaps, not acceptable target architecture for the rebuilt service. See `docs/CURRENT_STATE_AUDIT.md` and re-audit the local branch before changes.

## Existing local setup (current prototype)

Run these only after checking the current files and your local environment.

### Requirements

- Node.js compatible with `frontend/package.json` (the existing README specifies Node.js 20+).
- Python compatible with the current backend requirements (the existing README specifies Python 3.11+).

### Install

PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
npm --prefix frontend install
Copy-Item .env.example .env
```

If `.venv` already exists and is healthy, do not recreate it automatically. Never commit `.env`.

### Configure current integrations

The current prototype reads backend settings including:

```dotenv
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
ADAPTION_API_KEY=
APP_ENV=development
MAX_ANALYSIS_ROWS=80
PORT=8000
```

Do not paste keys into a prompt or commit them. Target reconstruction variables are described in `docs/DEPLOYMENT.md`; add variables to `.env.example` only when implementation actually needs them.

### Run locally

In one terminal:

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.main:app --reload --port 8000
```

In another terminal:

```powershell
npm --prefix frontend run dev
```

The existing Vite app is expected at `http://127.0.0.1:5173` and proxies `/api` to FastAPI. Recheck `frontend/vite.config.*` before relying on this.

### Existing test/build scripts

```powershell
npm --prefix frontend run typecheck
npm --prefix frontend test
npm --prefix frontend run build
.\.venv\Scripts\python.exe -m pytest
```

These commands are instructions, not a claim that the current tests passed. Record actual results during Phase 0.

## Target service architecture

The approved target direction is React/TypeScript, FastAPI, managed PostgreSQL, Supabase Auth, server-side Gemini integration, and a persisted Adaption job lifecycle. FastAPI remains the application API. All application records must be scoped to a verified user-owned workspace. See the architecture, database, security, and deployment docs for mandatory details.

## Release truth

A public URL alone does not make SignalIQ production-ready. Do not announce the reconstructed product as ready until signup/login, cross-account isolation, persistent records, analysis, issue tracking, reports, failure states, and the deployed smoke test have been verified. Billing, team collaboration, and live third-party feedback ingestion are not part of the first public-beta release.
