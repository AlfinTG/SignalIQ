# SignalIQ Reconstruction Documentation Bundle

This bundle is designed to be copied into the root of the existing `SignalIQ` repository. It intentionally contains documentation only; it does not change application source, dependencies, `.env.example`, database state, deployment settings, or screenshots.

## Copy layout

```text
SignalIQ/
├── AGENTS.md
├── README.md
└── docs/
    ├── CURRENT_STATE_AUDIT.md
    ├── PRD.md
    ├── UX_DESIGN_SPEC.md
    ├── DESIGN_SYSTEM.md
    ├── DEVELOPMENT_PHASES.md
    ├── ARCHITECTURE.md
    ├── DATABASE.md
    ├── API_CONTRACTS.md
    ├── AI_AND_ADAPTION.md
    ├── SECURITY.md
    ├── TESTING.md
    ├── DEPLOYMENT.md
    ├── DECISIONS.md
    ├── CODE_STYLE.md
    ├── PHASE_EXECUTION_TEMPLATE.md
    └── LEGACY_DOCUMENT_CLEANUP.md
```

## Before copying

1. Commit or otherwise preserve the current repository state.
2. Unzip this folder and copy `AGENTS.md` and `README.md` into the repository root, replacing their old versions.
3. Copy the contents of `docs/` into the repository's `docs/`, replacing old versions of matching files and adding new documents.
4. Do not replace or delete `images/`, `frontend/`, `backend/`, package lockfiles, `.gitignore`, `.env.example`, or the license as part of this documentation-only step.
5. Use `docs/LEGACY_DOCUMENT_CLEANUP.md` to deal with old duplicate `docs_bundle/` files deliberately after checking for unique content.
6. Review the resulting diff and commit/push the documentation checkpoint before asking Codex to edit application code.

## Important truth boundary

These docs define the **target product**. They do not claim that the target auth, database, visual system, persistence, training-label review, deployment, or tests have already been implemented. `docs/CURRENT_STATE_AUDIT.md` separates known existing implementation from unknowns that must be reverified on the local checkout.
