# API Contracts — SignalIQ

## General rules

- Prefix application routes with `/api`.
- All workspace-private routes require a valid bearer access token.
- The server derives user identity and allowed workspace from verified claims and database state; request-supplied IDs are selectors, not authorization.
- Use Pydantic request/response models, explicit status codes, bounded payloads, pagination, and stable error shapes.
- Return useful safe errors, not stack traces, prompt text, credentials, or raw provider dumps.
- Keep the actual contract and frontend client in sync. Change this document when an approved contract changes.

## Baseline endpoints

| Endpoint | Purpose | Required behavior |
|---|---|---|
| `GET /api/health` | Liveness/config summary | No secret material; do not expose privileged internal details. |
| `GET /api/me` | Current verified identity and workspace summary | Identity comes from the token, not a user ID passed in query/body. |
| `GET /api/workspace` | Current user's private workspace | Resolve/authorize workspace server-side. |
| `PATCH /api/workspace` | Update allowed workspace preferences | Allowlist editable fields. |
| `GET /api/feedback` | Search/filter/paginate records | Always workspace-scoped; support safe, bounded filters. |
| `POST /api/feedback` | Add feedback | Validate text, source, date, rating, and lengths. |
| `PATCH /api/feedback/{id}` | Correct editable feedback/labels | Check ownership and permitted state changes. |
| `DELETE /api/feedback/{id}` | Delete a record | Ownership check; confirm in UI; define effects on examples/reports. |
| `POST /api/feedback/import/preview` | Validate CSV and preview mappings | Enforce file size, row cap, encoding handling, and no silent row loss. |
| `POST /api/feedback/import` | Commit a validated import | Persist atomically or clearly report partial acceptance; do not double-import on retry. |
| `POST /api/feedback/analyze` | Analyze a bounded batch | Require auth; persist provenance/results; return per-record outcomes and partial failures. |
| `GET /api/analysis-runs` / `GET /api/analysis-runs/{id}` | View analysis history/status if implemented | Scope to workspace; avoid in-memory-only history. |
| `GET /api/issues` | Aggregate issue views | Compute aggregates from authorized current records. |
| `PATCH /api/issues/{issue_key}` | Update issue status/notes | Validate status; persist. |
| `GET /api/reports/preview` | Build report data for current scope | Calculate server-side or from trusted API data; preserve selected filters/date scope. |
| `POST /api/adaption/estimate` | Prepare dataset and ask for estimate | Verified examples only by default; real provider request; no run starts. |
| `POST /api/adaption/run` | Start run for previously estimated job | Require current owner and explicit confirmation; reject stale/unknown jobs. |
| `GET /api/adaption/jobs/{id}` | Refresh provider status | Read provider state and persist updates; authorize workspace ownership. |
| `GET /api/adaption/jobs/{id}/download` | Download output | Only when provider state/output permits; owner check; safe content headers. |

Endpoints may be consolidated when appropriate, but all behaviors and security boundaries must remain explicit. Do not create dead routes solely to match this table.

## Response/error shape

Use a consistent response format for failures, for example:

```json
{
  "error": {
    "code": "validation_error",
    "message": "Explain what needs to change.",
    "request_id": "optional-correlation-id"
  }
}
```

Do not include exception traces, API keys, user feedback unrelated to the caller, or complete provider payloads in an error response.

## Analysis contract requirements

Every result references a submitted stable record ID and has validated sentiment/category/issue key/severity fields. Model output may not create authoritative counts. Keep classification mode/provider/model and timestamp. Per-record failure should be represented honestly and must not erase valid existing classifications.

## Import contract requirements

Preview includes detected columns, selected mapping, row count, rejected row count, validation messages, and an import token or other safe way to bind confirmation to the previewed input. The server repeats validation when committing; it must not trust a browser-only preview.

## Adaption contract requirements

An estimate endpoint never launches a run. The run endpoint requires an explicit confirmation flag plus a valid persisted job owned by the caller. Idempotency protection should prevent accidental duplicate submissions. Provider statuses are normalized for UI use but retained sufficiently for audit/debugging. A job must survive backend restart because application metadata is persisted.
