# Testing and Quality Gates — SignalIQ

## Rules

- Test behavior, data consistency, authorization boundaries, and failure paths—not just whether a screen renders.
- Do not mark a check as passed if it did not run.
- Automated tests must not require live Gemini or Adaption credentials. Mock provider boundaries for deterministic tests and separately record credential-backed manual verification.
- Every fixed bug should receive a regression test where practical.

## Frontend checks

Use the scripts found in `frontend/package.json`; current expected scripts include:

```bash
npm --prefix frontend run typecheck
npm --prefix frontend test
npm --prefix frontend run build
```

Test:
- Route/navigation behavior, mobile menu, forms, keyboard focus and error messages.
- Loading, empty, filtered-empty, success, partial failure, session-expiry and provider-unconfigured states.
- Feedback filtering/sorting/pagination and active-filter consistency across KPIs, charts, issue lists, and reports.
- CSV mapping/preview/import feedback and safe handling of quotes, commas, Unicode, blank rows, malformed ratings/dates, duplicate retries, and formula-like cell content.
- Correct distinction between live AI, demo/rule outputs, unclassified data, and verified labels.
- Issue status changes persist after reload and update related pages.
- All buttons work or state why they are disabled; no placeholder actions.
- Responsive behavior around 390px and 1366px, and no unexpected horizontal page overflow.

## Backend checks

Run pytest using the repository's virtual-environment interpreter, for example:

```bash
.venv/bin/python -m pytest
```

On Windows PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pytest
```

Test:
- Token verification and invalid/expired-token rejection.
- Ownership authorization for all resource families.
- Two-user isolation across feedback, issue states, analysis, reports, and Adaption jobs.
- Request validation, maximum rows/text size, duplicate IDs and unknown fields as appropriate.
- Database persistence, transaction/error behavior, migrations on a fresh database and after upgrade.
- Gemini missing key, provider timeout/rate limit, malformed structured output, partial results, unexpected IDs and schema errors.
- Adaption missing key, insufficient/invalid examples, ingestion failure, estimate/run separation, confirmation required, timeout, provider failure, job persistence across process restart, and download-not-ready behavior.
- Health endpoint doesn't expose secret values or sensitive config.
- CSV/HTML export escaping and temporary-file cleanup.

## Business logic tests

- Sentiment/category aggregation matches underlying records.
- Priority component normalization, weight application, no-date/insufficient-date behavior, zero records and zero denominator.
- Issue grouping is deterministic and stable.
- Filters and date boundaries use a consistent timezone policy.
- Report scope, counts, and evidence match the selected workspace and filters.
- Provenance survives edits/re-analysis in an understandable way.

## End-to-end smoke test

At minimum, verify in a deployed or deployment-equivalent environment:
1. Create account A and sign in.
2. Import a small CSV and confirm accepted/rejected row counts.
3. Analyze a batch; verify a genuine live result or an explicitly labeled, intentionally selected demo state.
4. Open one issue and inspect source evidence and priority explanation.
5. Change its status, refresh, and verify persistence.
6. Export a report and compare its figures to the source data.
7. Sign out; create account B and verify no account A records are visible or accessible by direct API call.
8. Test missing provider credentials and a provider failure without losing data.
9. If Adaption credentials/credits are available, request estimate, verify no run starts, confirm a run, track actual provider status, and download actual output.
10. Repeat core navigation and the feedback list on a narrow viewport.

## Reporting format

For every phase, state exact commands, pass/fail/blocked status, number of tests when known, and blockers. Don't replace logs or failures with a vague “tested successfully.” If visual browser automation is unavailable, say so and list the manual checks completed or still needed.
