# Architecture — SignalIQ

## Status and target

This document describes the target architecture for the reconstruction, not a claim that these components already exist. The current prototype's confirmed limitations are in `CURRENT_STATE_AUDIT.md`.

## Architectural principles

- Preserve React/TypeScript/Vite/Tailwind and FastAPI unless a proven blocker exists.
- Keep the public frontend and application API deployable as one web service where practical; managed Auth/PostgreSQL and AI providers remain external services.
- Keep all private business logic, API secrets, model calls, and provider credentials on the server.
- Use Supabase Auth as the identity provider and managed PostgreSQL for durable application data.
- Make FastAPI the application API and persistence boundary in v1. The browser must not be allowed to bypass business authorization by submitting another workspace ID.
- Start with a private workspace per account. Team sharing and role matrices are deferred.
- Treat model output and imported customer text as untrusted input.

## Target component map

1. **Browser application:** React, TypeScript, React Router, Tailwind, Recharts, Lucide. Handles presentation, accessible state, form validation for usability, chart rendering, and calls to the API. It is not the authority for authorization or persisted analytics.
2. **Auth client:** Supabase Auth browser SDK for signup/signin/session refresh and logout. Only the supported publishable key may be present in the browser; no service-role or database credentials.
3. **FastAPI application:** validates bearer tokens, derives the authenticated user identity, authorizes resource/workspace access, validates requests, orchestrates Gemini/Adaption calls, persists results, and returns typed API responses.
4. **PostgreSQL:** primary source of truth for user workspaces, feedback, corrected/verified labels, issue states, analysis runs, and Adaption job metadata.
5. **Gemini provider:** used for current feedback classification and carefully constrained insights. Credentials live server-side. Application code calculates authoritative counts and scores.
6. **Adaption provider:** separate workflow for data optimization. It receives explicitly selected examples, returns provider job/status information, and provides an adapted dataset for downstream review/development.
7. **Hosting:** deploy frontend assets and API together if the selected host supports the needed runtime. The database/auth provider and model providers remain managed dependencies.

## Request flow

1. User authenticates through Supabase Auth.
2. Browser calls FastAPI with the access token.
3. FastAPI verifies token signature and required claims using the supported provider mechanism/library, rejects expired/invalid tokens, and derives the user ID from verified claims.
4. FastAPI resolves the user's workspace from the database; it must not trust an arbitrary user/workspace ID from the request as proof of access.
5. API validates input, performs an ownership-scoped database operation, and commits the result.
6. For AI jobs, API submits bounded/sanitized content to the provider, validates the structured result, persists the result/provenance, and returns an honest outcome.
7. Frontend updates views from the saved API response and refetches data when needed. It is never the only copy of user data.

## Data/access architecture

Use SQL migrations for all schema changes. SQL queries and ORM operations must constrain records by workspace derived from verified user identity. Use a least-privilege runtime database role. If any data endpoint is exposed directly through Supabase APIs, enable appropriate Row Level Security and grants for every exposed table and test both allowed and denied access. Do not assume RLS protects a connection authenticated as a table owner or a role that bypasses RLS; application authorization still has to be enforced.

## AI architecture

- Provider integration lives in focused backend modules.
- Request/response schemas are explicit and bounded.
- Analysis mode and model/provider version are retained with results.
- Priority aggregation, grouping, and counts are calculated by application code, never accepted from LLM-generated totals.
- A failed model call must not silently replace existing results with guessed labels.
- Rule-based fallback, when offered, must be an explicit user action or clearly disclosed state.

## Adaption architecture

Prepare examples from reviewed labels, preview/export them, upload and wait for ingestion, request an estimate, require fresh confirmation, start the real run, persist provider IDs/status, poll or refresh actual status, and download only when available. Keep the job state in PostgreSQL. Never use an in-memory dictionary as the sole persistent history. Adapted data is not automatically routed into live Gemini classification.

## Deployment architecture

- Build the frontend to static assets.
- FastAPI serves the built assets and `/api/*` routes, or use a separately hosted frontend only if the deployment plan deliberately chooses it.
- Configure `PORT` from the host environment and provide a health endpoint without exposing credentials.
- Keep `.env` local and use host-managed secret settings in production.
- Configure database migrations and a repeatable deployment procedure before public release.

## Reliability and scale boundary

The first public beta prioritizes correctness over elaborate infrastructure. Keep analysis batches bounded and expose timeouts/rate-limit errors. Do not introduce Redis, a distributed task queue, microservices, streaming or a vector database without a demonstrated requirement. If job durations or concurrency make synchronous operations unsuitable, document the need and choose the simplest durable job mechanism before implementation.
