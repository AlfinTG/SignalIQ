# Code Style and Implementation Conventions

## General
- Prefer clear, idiomatic, maintainable code over clever abstractions or broad rewrites.
- Follow the existing folder conventions where possible; change them only for a documented reason.
- Keep components/modules focused and name them by responsibility.
- Avoid duplicate business logic between frontend and backend. Server-persisted business rules and authorization are authoritative.
- Keep comments focused on why behavior/constraints exist, not a restatement of the line.
- Do not add dependencies without a concrete need; inspect current lockfiles/manifests first.

## TypeScript / React
- Use strict types and meaningful domain types; avoid `any`.
- Keep API client functions and data transformations out of complex presentational components.
- Use controlled forms where predictable validation/state is needed; display actionable validation errors.
- Use semantic elements, accessible names, visible focus, and keyboard-operable dialogs/navigation.
- Ensure async components handle loading, success, empty, partial failure, and error states.
- Never hardcode production-looking metrics in a component. Use fixtures only through explicitly identified development/demo paths.
- Avoid global shared state unless it serves a real cross-screen concern; do not recreate `localStorage` as the authoritative persistence layer.

## Python / FastAPI
- Use explicit types, Pydantic models, small service modules, and clear error mapping.
- Keep provider SDK calls behind focused modules so they can be mocked in tests.
- Validate request size, row limits, enums, and output schemas at trust boundaries.
- Use parameterized SQL/ORM operations and workspace-scoped queries.
- Do not return exception traces, raw secrets, or complete sensitive provider payloads to callers.
- Avoid module-level in-memory structures for state that must survive restart or support multiple workers.

## Data, AI, and exports
- Give analysis outputs an explicit provenance/mode and timestamp.
- Compute counts, grouping, ranking and priority values in tested application code.
- Treat LLM output as untrusted even if the provider returns structured JSON.
- Escape HTML and spreadsheet-oriented exports; test formula-injection behavior.
- Avoid logging raw feedback text unless explicitly necessary and privacy-approved.

## Tests and versioning
- Add regression tests for changed behavior and authorization boundaries.
- Pin/lock dependencies through the repository's established package tooling.
- Use repeatable migrations and update docs when an API/data contract changes.
- A successful build is not proof of feature correctness; verify the end-to-end user journey.
