# Development Phases — SignalIQ Reconstruction

## Working rule

One phase per Codex task. Read the phase's acceptance criteria before coding. Do not proceed when a required gate is blocked. The user approves the phase handoff before the next phase begins. Time estimates are intentionally not used as scope constraints; quality and verified outcomes govern progression.

## Phase 0 — Repository audit and documentation reset

**Goal:** establish a correct shared understanding before app edits.

Work:
- Inspect working tree, branch, dependencies, tests, frontend/backend source, images, and existing deployment files.
- Verify the current state against `CURRENT_STATE_AUDIT.md`.
- Replace contradictory documentation with the canonical bundle and remove/move obsolete prompt bundles after preserving any useful unique content.
- Keep this checkpoint documentation-only unless explicitly approved otherwise.

Gate:
- Documents agree with one another.
- Existing code/feature state is marked implemented, unverified, or planned.
- No secrets or user data are added.
- Diff is reviewed and documentation commit pushed by the user.

## Phase 1 — UX architecture and design lock

**Goal:** design the product before rewriting page components.

Work:
- Inspect all repository screenshot references at readable resolution.
- Produce a screen inventory, user flows, component inventory, responsive layouts, states, and design tokens.
- Establish visual hierarchy and the warm editorial analytics direction.
- Review all interactive controls and determine their real behavior.

Gate:
- UX spec and design system are internally consistent and tied to requirements.
- Core desktop and mobile layouts and states are covered.
- User approves the design baseline before broad component implementation.

## Phase 2 — Frontend reconstruction

**Goal:** replace prototype-style screens with the approved interaction model.

Work:
- Rebuild application shell and route structure.
- Implement public/auth screens and core workspace screens with accessible, responsive components.
- Create typed API/data-access boundaries and development fixtures clearly isolated from production.
- Implement all visual states and working local interactions that do not depend on completed backend endpoints.

Gate:
- Routes/navigation work; no dead buttons; no console errors known to be caused by the implementation.
- Desktop/mobile layouts checked; typography and tokens are consistent.
- Charts and KPIs use fixtures or current API data—not hardcoded illustrative totals in product logic.
- Frontend typecheck, tests, and build run with outcomes documented.

## Phase 3 — Authentication, database, and persistent service API

**Goal:** replace browser-only workspace persistence with authenticated durable records.

Work:
- Implement Supabase Auth integration and FastAPI request authentication based on verified access tokens.
- Add database schema/migrations for workspaces, feedback, issue states, analysis runs, verified training examples, and Adaption jobs.
- Create per-user private workspace on onboarding.
- Add ownership-scoped CRUD/list/filter/import APIs, input validation, pagination and limits as required.
- Migrate a user's local prototype data only if there is a deliberate migration path and user consent; do not silently upload it.

Gate:
- Two test accounts cannot read/change each other's data.
- Data persists across refresh, different browser/device session, and service restart.
- Migration setup is repeatable; important queries use indexes and transaction boundaries where appropriate.
- Authorization tests cover allow and deny cases.

## Phase 4 — AI analysis and explainable insight engine

**Goal:** connect the redesigned experience to real, safe, evidence-backed analysis.

Work:
- Integrate and harden existing server-side Gemini code.
- Persist analysis runs and per-record provenance/status.
- Validate model output; handle partial failures, timeouts, rate limits, missing keys and malformed JSON.
- Group recurring issues and calculate metrics/priorities in deterministic application code.
- Add review/correction flows and verified label states.

Gate:
- Successful results are persisted and traceable to source feedback.
- Failed outputs do not overwrite valid data or create fabricated classifications.
- Score math, no-date behavior, empty data, duplicate records, and filters are tested.
- Live provider use is tested only when credentials are available; no credentials are required for automated unit tests.

## Phase 5 — End-to-end feedback, actions, reports, and Adaption

**Goal:** complete the user's full workflow.

Work:
- Connect import, add/edit, filters, issue details, status changes, recommendations, and report export to persistent APIs.
- Make all dashboards/report calculations consistent with current data and filters.
- Implement verified training-example selection, dataset preview/export, estimate → explicit confirm → provider status → output download.
- Persist Adaption job metadata and enforce workspace ownership on every job route.

Gate:
- Complete smoke flow passes: import → analyze → inspect evidence → update issue status → export report.
- Adaption workflow handles missing credentials, estimate errors, confirmation, running, failure, restart/reload, and download states honestly.
- A real Adaption run is only claimed verified after actual credentials/provider result are available.

## Phase 6 — Hardening, deployment, and release verification

**Goal:** make the product safe and reliable for public-beta users.

Work:
- Run frontend tests/typecheck/build, backend tests, migration checks, API/auth integration tests, and available end-to-end tests.
- Inspect responsive behavior, keyboard accessibility, empty/error states, CSV/HTML export safety, logs, rate limits and data ownership.
- Configure production secrets and managed services; deploy; verify health, auth, database, AI, core workflows, and the public URL.
- Update README and known limitations based on actual evidence.

Gate:
- No unresolved critical security or data-isolation issue.
- Build and required tests pass or any skipped check is explicitly justified and blocks release when critical.
- Deployed smoke-test evidence is recorded, and production setup is repeatable.
- No feature is claimed live unless it has been verified on the deployed build.

## Change control

If a phase uncovers a necessary architecture change, stop before broad implementation, document the issue in `DECISIONS.md`, explain the impact and alternatives, and obtain approval. Do not quietly expand scope or add services.
