# UX Design Specification — SignalIQ

## Goal

Build a coherent, premium-feeling analytical workspace that makes feedback easier to understand and decisions easier to act on. The experience should feel intentionally designed, not like a generic AI-generated admin panel.

## Visual/product reference handling

The repository contains `images/Dashboard reference.png`, `images/Feedback Explorer reference.png`, and `images/Insights and Actions reference.png`. During Phase 0, open and inspect each image at readable resolution. Record useful layout, hierarchy, density, interaction, and chart ideas. Do not infer the contents from filenames, and do not copy a reference element that undermines the new product requirements.

Use the reference images together with `docs/DESIGN_SYSTEM.md`. The new direction is warm editorial analytics: warm ivory/stone surfaces, charcoal text, forest/sage green, limited terracotta/amber, clean data visualization, and carefully varied layouts.

## Information architecture

### Public/authentication routes
- Landing page: clear statement of the user problem, product workflow, representative product preview, and a clear sign-in/create-account action. Keep it concise and credible.
- Sign up / sign in / recovery: accessible forms with field labels, validation, password visibility where applicable, loading/error feedback, and the auth provider's supported recovery flow.

### Authenticated workspace
1. Overview
2. Feedback Explorer
3. Insights
4. Priorities & Actions
5. Reports
6. Data Quality & Adaptation (advanced capability; visually secondary to the core feedback workflow)
7. Workspace settings/account menu

A persistent shell contains the SignalIQ mark/name, main navigation, workspace/account context, and appropriate page-level actions. Do not cram every tool into the primary navigation.

## Screen requirements

### Overview
- Page title and concise contextual sentence.
- One clear primary action: add/import feedback or analyze pending records, depending on workspace state.
- KPI row with labels, date/filter context, and useful comparisons only when valid.
- Sentiment distribution and feedback-over-time visualization; filters/range controls must affect visible data.
- Top recurring issues with severity/priority context.
- A prioritized next-action section linking directly to issue details.
- Sample-data banner for a sample workspace; setup guidance for an empty workspace.

### Feedback Explorer
- Search, sort, and filters for sentiment, category/issue, source, rating, date, and analysis status where available.
- CSV import flow: select file → map columns → preview/validate → confirm import → display accepted/rejected counts.
- Manual entry with required text and optional date, source, rating; accessible validation.
- Feedback detail panel/page with original text, source/date, analysis result, explanation, category, sentiment, severity, and classification provenance.
- Allow correction/re-analysis when authorized; explain if a result is a demo/rule result.
- Use responsive cards on narrow viewports or controlled horizontal table scroll, never tiny unreadable columns.

### Insights
- Issue/theme groups tied to source feedback records.
- Detail views include a plain-language statement, counts, time range, sentiment breakdown, evidence excerpts, and known uncertainty.
- Recommendations describe concrete actions and show which observed pattern supports them. No generic recommendation that implies unsupported evidence.
- Distinguish discovered patterns from an AI-generated explanation or a rule-based recommendation.

### Priorities & Actions
- Sortable priority list with status, severity, feedback count, negative share, trend availability, and score.
- Issue detail with transparent score components and the actual supporting comments.
- Status changes (`Open`, `In progress`, `Resolved`) persist and update all views.
- Provide useful confirmation only for genuinely destructive operations; don't over-confirm normal navigation.

### Reports
- Choose date range and dataset scope.
- Preview included KPIs, top issues, score details, recommendations, evidence, and limitations.
- Export at least one useful report format plus CSV data where applicable.
- Report generation must respond to errors and must not claim stale filters or data are current.

### Data Quality & Adaptation
- Secondary workflow, separate from live analysis.
- Explain that Adaption optimizes training data, not the active SignalIQ classifier.
- Show source examples, human-reviewed label state, target output, exclusions, column mapping, row count, and downloadable pre-run dataset.
- Show configured/not-configured state without revealing credentials.
- Display real estimates and their units; require explicit confirmation before run.
- Persist job metadata, poll real status, provide honest provider errors, and enable output download only when valid.

### Settings
- Account/session controls, private workspace context, and configuration/connection status relevant to the user.
- Never display API secret values.
- Admin-managed provider secrets are configured on the server, not entered into client-side settings in v1.

## Shared interaction states

Every data-driven screen needs loading/skeleton, populated, empty, filtered-empty, partial failure, full failure, unauthorized/session-expired, and retry states where relevant. Every action must show a clear result. Avoid success toasts before an API has actually succeeded.

## Responsive/accessibility requirements

- Support approximately 390px mobile and 1366px desktop widths.
- No horizontal page overflow at target widths.
- Visible keyboard focus and fully keyboard-operable navigation, forms, menus, and dialogs.
- Semantic headings, form labels, accessible names for icon-only buttons, sensible focus order, and sufficient contrast.
- Charts need text labels/legends or an equivalent readable summary; don't rely on color alone.
- Respect reduced-motion preferences. Animations, if any, should reinforce state changes rather than decorate every element.

## UX acceptance checks

- A first-time user can identify the main action without reading a manual.
- A user can trace each important insight to source comments.
- Every chart/KPI responds to the same selected dataset and filters.
- A user can distinguish live AI from demo analysis.
- All important controls work with keyboard and at mobile widths.
- Screens use a consistent design system but not an endless grid of identical cards.
