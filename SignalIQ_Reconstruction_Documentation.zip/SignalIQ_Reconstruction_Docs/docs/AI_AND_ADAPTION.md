# AI and Adaption — SignalIQ

## 1. Two separate capabilities

SignalIQ contains two different workflows:

1. **Live feedback analysis:** uses Google Gemini via the SignalIQ backend to classify current customer comments and help explain recurring patterns.
2. **Training-data improvement:** uses Adaption Adaptive Data to prepare/optimize a curated dataset for downstream training or evaluation.

Do not describe Adaption as SignalIQ's current live sentiment classifier. Adapted output must not be put into live inference unless a separate model-training/integration phase and evaluation explicitly establishes that behavior.

Official integration references:
- Adaption Adaptive Data quickstart: https://docs.adaptionlabs.ai/adaptive-data-quickstart
- Create a dataset: https://docs.adaptionlabs.ai/adaptive-data/create-a-dataset/
- Adapt a dataset/estimate: https://docs.adaptionlabs.ai/api/python/resources/datasets/methods/adapt/
- Download processed dataset: https://docs.adaptionlabs.ai/api/python/resources/datasets/methods/download
- Supabase auth guide: https://supabase.com/docs/guides/auth/server-side/creating-a-client
- Supabase RLS guide: https://supabase.com/docs/guides/database/postgres/row-level-security

Check current official documentation and installed SDK version before changing provider calls. Do not assume a method or return type based on an older SDK release.

## 2. Gemini live-analysis workflow

Input is a bounded set of feedback records. The backend should:
1. Check authentication and workspace ownership.
2. Validate record IDs and text lengths; apply configured request/batch limits.
3. Remove obvious email/phone patterns where appropriate, without claiming this fully anonymizes data.
4. Send only the necessary fields to Gemini using structured-output constraints supported by the chosen model/API version.
5. Validate every returned item against a schema and ensure IDs correspond to the requested batch.
6. Reject impossible enum values, excessive field lengths, malformed JSON, and unsupported claims.
7. Persist accepted results and provenance transactionally; preserve previous valid results for failed records.
8. Return success/partial failure with useful status and safe error details.

Suggested classification fields: `sentiment`, `category`, normalized `issue_key`, `severity`, concise `summary`, evidence-grounded `explanation`, `suggested_action`, and `confidence` only if the application can define its meaning. Do not treat an LLM's self-reported confidence as calibrated probability without evaluation.

Counts, sentiment percentages, issue frequencies, trends, and priority scores must be computed by application code from persisted records—not accepted from model text. Insights should cite feedback IDs/excerpts and acknowledge missing evidence. Recommendations must not invent root causes that the comments do not support.

### Fallback policy

A deterministic rules-based analysis may be offered when live AI is unavailable, but it must be clearly labeled as demo/rules-based and store provenance accordingly. For production user data, don't silently switch from a requested live model call to fallback results. Show a missing-configuration/provider-error state and let the user explicitly choose a fallback if that path is retained. Never claim a model succeeded after an HTTP/provider error.

## 3. Issue aggregation and priority

Start with the documented heuristic:

`0.40 × Frequency + 0.30 × NegativeRate + 0.20 × Trend + 0.10 × Severity`

Every component is normalized to 0–100 and each normalization is documented in code/tests. If trend/date coverage is insufficient, mark it unavailable and redistribute its weight proportionally among available components. This is a transparent initial product heuristic—not an externally validated business-impact formula. Include a score breakdown and enough evidence for users to challenge it.

## 4. Human review and training example quality

Current code creates task examples from records that have already received live or demo classifications. That is not equivalent to verified ground truth. The reconstructed workflow must:
- Show the original feedback and candidate target label/output.
- Show the provenance of the candidate label (`Gemini`, `rules/demo`, `user corrected`, or `synthetic`).
- Allow an authorized user to correct fields and mark an example `verified` or `rejected`.
- Include only verified examples by default in an Adaption dataset used as trusted training data.
- Warn on synthetic, heuristic-derived, duplicate, contradictory, or very similar examples; deduplicate carefully without silently removing meaningful cases.
- Let a user preview, export, and confirm the exact selected dataset before uploading it externally.
- Avoid sending data the user has not selected/authorized to an external provider.

Human verification improves dataset provenance; it does not, by itself, prove a label is objectively correct. Keep the verified-by/time trail and allow users to inspect examples.

## 5. Adaption Adaptive Data workflow

Target flow:
1. Select eligible verified training examples and set a row cap.
2. Preview the columns/rows and download a local CSV/JSONL copy.
3. Validate minimum row count, text length, schema, and allowed labels.
4. Upload the dataset using the supported SDK method and capture the returned dataset ID.
5. Poll ingestion status until the provider confirms readiness or reports a failure/timeout.
6. Request `datasets.adapt(..., estimate=True)` with the verified current column mapping.
7. Show provider-returned credit/time estimates and explain that a real run may consume credits.
8. Require a separate explicit confirmation before calling the real adaptation operation without `estimate=True`.
9. Persist the application job, workspace owner, provider dataset/run identifiers, estimate, phase/status and timestamps.
10. Poll/refresh actual provider status; normalize known success/failure states without pretending unknown states are success.
11. Download actual processed output only when provider state permits it. Handle partial output after failure according to current provider documentation.
12. Let the user inspect the output and export it for a downstream model-development/evaluation workflow.

The code must be tested against the pinned/current supported SDK. The official docs show `upload_file`, `get_status`, `adapt` with `estimate=True`, an actual `adapt` call for the run, and `download`; response shapes differ by SDK version, so follow current docs rather than hardcoding assumptions from an old version.

## 6. Data governance for external AI providers

- Keep Gemini/Adaption keys server-side only.
- Explain to users before external processing which selected content is transmitted and to which provider.
- Apply request size/rate limits and a clear user confirmation for external dataset upload/run.
- Avoid sending direct identifiers and sensitive data where possible; simple regex redaction is not anonymization.
- Do not log complete customer comments or secrets in production by default.
- Establish retention/deletion expectations for source files, temporary files, external datasets, job history, and exported reports. Do not promise provider-side deletion without verified support.

## 7. Evaluation before model replacement

An adapted dataset is not a model. If a later phase introduces training or uses an adapted model for inference, require:
- A held-out evaluation set not used to construct the adaptation data.
- Documented baseline metrics and chosen quality thresholds.
- Checks for label leakage, duplicates and class imbalance.
- Comparison against the current Gemini/rules workflow.
- A rollback path and explicit approval before changing live inference.

AutoScientist, custom fine-tuning, automated model promotion, and automatic production model replacement are outside v1.
