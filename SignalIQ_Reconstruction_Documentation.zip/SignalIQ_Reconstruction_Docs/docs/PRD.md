# Product Requirements — SignalIQ

## 1. Product definition

**Name:** SignalIQ  
**Tagline:** Find the signal. Fix the problem.  
**Category:** Customer Feedback Intelligence & Decision Platform

SignalIQ helps a business make better product and service decisions by turning unstructured customer feedback into traceable insights, explainable priorities, tracked follow-up, and reports.

## 2. Problem

Customer feedback is scattered across reviews, surveys, support messages, and manually collected comments. Teams struggle to identify repeated pain points, distinguish isolated complaints from growing problems, understand the evidence behind a recommendation, and track whether corrective action happened.

SignalIQ must connect the complete journey from the source comment to the recommended action. It must not stop at a sentiment chart or an AI-generated paragraph.

## 3. Primary users

- **Small-business owner/product lead:** needs a clear view of customer pain and what to fix first.
- **Support/customer-experience analyst:** imports feedback, checks classifications, and investigates patterns.
- **Product or operations manager:** tracks issue status and prepares a report for stakeholders.

First release supports separate individual accounts with a private workspace per user. Shared team workspaces, member invitations, granular organizational roles, and billing are later scope.

## 4. Product principles

1. Evidence before assertions: insights link to real source feedback.
2. Explainable priorities: the user can see which signals influenced a score.
3. Honest AI: live model, rules-based demo, unclassified, and failed states remain distinguishable.
4. User control: users can correct labels and explicitly confirm potentially billable Adaption runs.
5. Durable state: user data is stored server-side and survives refresh, sign-in on a second device, and service restarts.
6. Calm, distinctive UX: editorial hierarchy, warm neutrals, natural accent colors, useful whitespace, and no generic AI-dashboard look.
7. Secure by default: account data is private and each API operation is authorized on the server.

## 5. Core user journeys

### A. First visit

User visits the service, understands what it does, creates an account or signs in, and sees a useful onboarding step. Synthetic sample data is clearly labeled. No account should inherit another user's records.

### B. Import feedback

User uploads a supported CSV or adds individual comments. The app previews the detected columns, allows correction if mapping is ambiguous, validates row limits and fields, reports accepted/rejected rows, and stores valid records in the user's workspace. It must never silently discard data.

### C. Analyze and inspect

User selects unclassified or chosen records and starts analysis. The app shows progress and reports failures. Classifications are persisted with provider/mode, model or rule version, confidence when available, and timestamps. Users can inspect the reason and edit incorrect labels.

### D. Discover and prioritize

The app groups related feedback into issue themes. Each issue shows volume, sentiment distribution, date coverage, severity signals, recent movement when calculable, a transparent priority score, supporting comments, and a specific action recommendation tied to observed evidence.

### E. Track action

A user changes an issue from `Open` to `In progress` to `Resolved`. Changes persist and affect subsequent screens and reports. Resolution does not delete the supporting feedback or erase history.

### F. Generate a report

User selects a date range and dataset scope and generates a downloadable report. Metrics, rankings, and evidence reflect the selected data at generation time. The report states date coverage and important limitations.

### G. Improve training data with Adaption

User reviews and verifies labels, selects eligible examples, inspects the dataset and column mapping, exports a local copy, requests a genuine Adaption estimate, and explicitly confirms any run that may consume credits. The app persists job metadata, displays provider-reported status, and enables download only when the provider makes output available.

## 6. Functional requirements

### Accounts and workspaces
- FR-01: Users can sign up, sign in, sign out, and recover access using the selected auth provider's supported flow.
- FR-02: A new user receives a private default workspace.
- FR-03: The server verifies identity and workspace ownership for every private API operation.
- FR-04: User data remains isolated across accounts. Team collaboration is out of scope for v1.

### Feedback collection and management
- FR-05: Add, inspect, edit, filter, search, sort, and delete feedback, with safe confirmation where destructive.
- FR-06: Import CSV with common aliases for comment text, date, source, and rating.
- FR-07: Report malformed, blank, duplicate, rejected, and imported rows clearly.
- FR-08: Keep synthetic sample data clearly labeled and make it possible to remove it without touching real records.
- FR-09: Keep source metadata, original text, creation time, and import provenance where available.

### Analysis and insights
- FR-10: Classify sentiment as positive, neutral, or negative; use `unclassified` as application state when no valid result exists.
- FR-11: Produce category/theme, normalized issue key, severity, evidence-grounded explanation, suggested action, provenance, and confidence where the provider genuinely supplies a usable confidence estimate.
- FR-12: Group recurring issues deterministically and show supporting feedback records.
- FR-13: Compute overview metrics from persisted records and active filters; no hardcoded production KPIs.
- FR-14: Show temporal trends only when date quality and sample size support them; otherwise state that trend is unavailable.
- FR-15: Allow a user to correct classifications and mark training examples verified.
- FR-16: Distinguish Gemini results from any deterministic rule-based fallback. A fallback never masquerades as model output.

### Priorities and actions
- FR-17: Calculate a documented 0–100 priority score and expose the score breakdown.
- FR-18: Let users save/unsave issues and change their status.
- FR-19: Tie recommendations to actual issue evidence and label heuristic recommendations as such when generated by rules.

### Reports and exports
- FR-20: Export valid feedback CSV and a readable report (HTML or another verified download format).
- FR-21: Escape untrusted values in HTML and spreadsheet-compatible CSV outputs; do not execute imported content.
- FR-22: Include report scope, date range, metrics, top issues, priority breakdown, recommendations, evidence, and limitations.

### Adaption
- FR-23: Build training examples from explicitly reviewed/verified labels; synthetic or heuristic-labeled records must be marked as such.
- FR-24: Show the exact dataset selection and column mapping before upload/run.
- FR-25: Request an estimate before a potentially billable operation and require a separate confirmation action.
- FR-26: Persist application job metadata and display genuine provider state, errors, and downloadable output where available.
- FR-27: State clearly that adapted output is a dataset for downstream training/evaluation, not an already trained or deployed SignalIQ model.

### Service quality
- FR-28: Provide useful loading, empty, success, partial-failure, offline, missing-configuration, and error states.
- FR-29: Core interactions work at mobile and desktop widths and via keyboard.
- FR-30: A production build and documented smoke-test sequence pass before release.

## 7. Priority score

Retain the current formula as an initial transparent heuristic, not an industry-validated model:

`Priority = 0.40 × Frequency + 0.30 × NegativeRate + 0.20 × Trend + 0.10 × Severity`

Each component is normalized to 0–100 with the exact method documented and unit-tested. If trend is unavailable, redistribute its weight proportionally among available components and explicitly disclose the missing trend signal. Avoid division-by-zero. Keep this heuristic versioned so it can be calibrated with real users later.

## 8. Non-goals for the first public beta

- Billing, paid plans, subscription management.
- Team invitations, shared collaboration, and complex role matrices.
- Live ingestion from third-party review/helpdesk platforms.
- Automatic customer replies or changes to external business systems.
- Fine-tuning, deploying, or routing live inference to an adapted model.
- AutoScientist or autonomous model research.
- Claims of statistically validated business-impact prediction.

## 9. Release acceptance

The public beta is accepted only when a user can register/sign in, import or add feedback, persist it, analyze and inspect results, review supporting evidence, prioritize and track an issue, export a report, and use correctly gated Adaption flows when credentials are configured. At least two independent accounts must be tested to confirm isolation. Required tests, production build, health check, and deployed smoke tests must have actual recorded outcomes.
