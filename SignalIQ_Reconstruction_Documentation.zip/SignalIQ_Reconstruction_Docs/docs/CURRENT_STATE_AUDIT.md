# Current-State Audit — SignalIQ

**Purpose:** Preserve what is known about the existing repository and prevent documentation from presenting planned work as implemented functionality.

## Baseline inspected

The public repository `AlfinTG/SignalIQ` has a React/Vite frontend and a FastAPI backend. The source tree includes `AGENTS.md`, `README.md`, frontend pages/components and tests, backend API/provider code and tests, `docs/`, older `docs_bundle/` content, and reference screenshots under `images/`.

Re-run this audit against the checked-out local branch before editing. Repository contents may change after this audit.

## Verified from repository text/source

| Area | Existing state | Implication |
|---|---|---|
| Product instructions | Existing `AGENTS.md` frames the work as a roughly nine-hour hackathon prototype and says not to add auth or a database. | Replace these instructions; do not let them govern reconstruction. |
| Product scope | Existing `docs/PRD.md` lists auth, billing, third-party review ingestion, and custom training as non-goals. | Keep only relevant non-goals; auth and persistent storage become first-release requirements. |
| Design | Existing design system specifies navy navigation and blue accent. | Replace the visual direction with the warm editorial analytics system. |
| Frontend persistence | `WorkspaceContext` loads/saves workspace state using browser `localStorage`. | Replace as the source of truth for signed-in user data. |
| Backend | `backend/main.py` exposes health, analysis, and Adaption endpoints and serves built frontend assets when present. | Preserve useful API/provider code while adding auth and persistence. |
| Gemini | `backend/gemini_client.py` and `/api/analyze` implement a server-side provider path with validated response schemas. | Audit provider behavior and reuse where safe; test live calls separately. |
| Demo analysis | Frontend rule-based fallback exists and is disclosed as demo analysis. | Preserve honest provenance; never label rule output as live AI. |
| Adaption | `backend/adaption_service.py` uploads data, estimates, runs after confirmation, polls status, and downloads JSONL. | This is a real code path, but live execution is not verified by this audit. |
| Adaption jobs | Current code stores job metadata in an in-memory dictionary. | Persist metadata before claiming restart-safe workflows. |
| Adaptation data quality | `frontend/src/lib/adaptionDataset.ts` builds examples from already-classified records; it does not require human review of every label. | Add explicit label review and verified-example selection. |
| Database/auth | Current docs/source identify no primary application database and no auth workflow. | Build both; do not treat client-provided workspace IDs as authorization. |
| Tests | Frontend and backend test files exist in the repository. | Existence is not a passing result; run and document their outcomes. |
| Deployment | The backend can serve frontend build output and reads `PORT`. | This is a deployment path, not proof a production deployment exists. |

## Not verified in this audit

- Whether all frontend/backend tests pass on the user's local checkout.
- Whether Gemini or Adaption credentials are configured and live calls succeed.
- Whether any deployed URL exists, is current, or passes end-to-end checks.
- Whether current database/auth infrastructure already exists outside this repository.
- Whether the reference screenshots correspond to the latest desired screens.

Codex must inspect the actual images in `images/` by opening them; filenames alone are insufficient. The three known filenames are `Dashboard reference.png`, `Feedback Explorer reference.png`, and `Insights and Actions reference.png`.

## Required Phase 0 result

Create or update a factual audit in the working branch containing the checked-out commit, actual command results, current visual observations, reusable code, required replacements, blockers, and differences from this file. Do not edit application code as part of the documentation-only reset unless explicitly instructed.
