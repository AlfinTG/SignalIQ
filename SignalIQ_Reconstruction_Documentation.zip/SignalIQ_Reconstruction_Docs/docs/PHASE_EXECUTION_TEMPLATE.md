# Codex Phase Prompt Template — SignalIQ

Copy this template for one phase at a time. Replace bracketed fields before sending the task to Codex.

---

You are working in the existing SignalIQ repository. The goal is to reconstruct the existing application into the product described by the canonical docs, not generate a separate replacement project.

## Phase
**[PHASE NUMBER AND NAME]**

## Read first
1. `AGENTS.md`
2. `docs/DECISIONS.md`
3. `docs/PRD.md`
4. `docs/DEVELOPMENT_PHASES.md`
5. [relevant design/architecture/security/testing docs]
6. Relevant implementation files, tests, assets, and repository status

## Objective
[State one measurable objective. Do not include work assigned to later phases.]

## Scope
**Must do:**
- [deliverable]
- [deliverable]

**Must not do in this phase:**
- Do not implement later phases.
- Do not replace the whole repository or delete useful assets.
- Do not introduce an undocumented stack/service or silently reverse a decision.
- Do not add mock “success” states for real integrations.

## Acceptance criteria
- [observable behavior or artifact]
- [relevant test/verification]
- [state/authorization/data integrity requirement]

## Execution requirements
1. Inspect the actual code and working tree before editing.
2. Preserve unrelated user changes. If the working tree is dirty or a destructive change appears necessary, explain the risk before proceeding.
3. Implement only the assigned phase; don't stop after writing a plan if the task asks for implementation.
4. Add or update tests appropriate to the changes.
5. Run the checks available for the changed code and fix regressions caused by the implementation.
6. Update documentation if the implementation changes an approved contract; record architecture changes in `docs/DECISIONS.md` and flag them for approval when required.
7. Review the diff for dead controls, hardcoded metrics, leaked secrets, data leaks, and misleading claims.

## Required final report
- Scope completed and files changed.
- Tests/checks executed, with actual commands and results.
- Acceptance criteria passed/failed/blocked.
- Features that are implemented and verified, implemented but unverified, or still planned.
- Exact blockers or manual/credential-backed checks that remain.
- Suggested next phase only; do not start it automatically.

Begin by inspecting the repository and current phase context.
