# Product and Architecture Decisions — SignalIQ

This file is the canonical record of approved reconstruction choices. Change it deliberately when evidence or product intent changes. When changing a decision, include context, chosen option, alternatives, consequences, and affected docs.

## D-001 — Active product name
**Status:** Accepted for reconstruction  
**Decision:** The user-facing product is **SignalIQ**, tagline **Find the signal. Fix the problem.** `InsightFlow` is historical name/context from earlier hackathon material and must not appear as the active product brand.  
**Reason:** One consistent identity prevents coding-agent naming drift.

## D-002 — Product is a usable public-beta service, not a nine-hour demo
**Status:** Accepted  
**Decision:** Product requirements prioritize complete core workflows, durable data, account isolation, and verification over a time-boxed mockup.  
**Consequence:** Remove the old nine-hour constraint and old instructions that explicitly prohibit authentication and databases.

## D-003 — Preserve the existing stack where practical
**Status:** Accepted  
**Decision:** Keep React + TypeScript + Vite + Tailwind + Recharts/Lucide and Python FastAPI/Pydantic unless Phase 0 finds a concrete blocker. Keep useful Gemini/Adaption provider modules where safe.  
**Consequence:** Rebuild the experience and architecture incrementally; do not rewrite everything without evidence.

## D-004 — Visual direction
**Status:** Accepted baseline, tune during Phase 1  
**Decision:** Warm editorial analytics: ivory/stone backgrounds, charcoal text, muted forest/sage green, restrained terracotta/amber, varied layouts, purposeful data visualizations.  
**Consequence:** The old dominant navy/blue dashboard direction is superseded.

## D-005 — Authentication and persistence
**Status:** Accepted target architecture  
**Decision:** Use Supabase Auth and managed PostgreSQL as the target identity/data foundation, with FastAPI as the application API. Start with one private workspace per user; no team sharing in v1. Confirm exact SDK/database connection implementation in Phase 3 against current official docs.  
**Consequence:** Browser localStorage is not the source of truth for user feedback/issue state. Every request is owner-scoped server-side. Apply and test RLS correctly wherever a connection path relies on it; don't assume an owner/service role is restricted by RLS.

## D-006 — Gemini and Adaption are separate
**Status:** Accepted  
**Decision:** Gemini performs current feedback analysis. Adaption Adaptive Data optimizes a curated training dataset. Adaption output is not automatically routed into live analysis.  
**Consequence:** Any future adapted-model path needs separate model training/integration and evaluation before promotion.

## D-007 — Human-reviewed adaptation examples
**Status:** Accepted  
**Decision:** Provide provenance and a review/correction state; only verified examples are eligible for the trusted adaptation dataset by default.  
**Consequence:** Existing code that turns already-classified comments directly into examples must be upgraded; model/rules output is not automatically ground truth.

## D-008 — Adaption run controls and persistence
**Status:** Accepted  
**Decision:** Prepare/preview dataset, request estimate, require separate explicit confirmation, run, report actual status, persist application job metadata, and download actual output only when available.  
**Consequence:** No automatic/billable run on page load and no in-memory-only application job registry in the target release.

## D-009 — Explainable heuristic priorities
**Status:** Accepted baseline  
**Decision:** Begin with frequency 40%, negative rate 30%, trend 20%, severity 10%, with components normalized to 0–100 and weights disclosed. If trend is unavailable, redistribute that weight among available components and mark trend unavailable.  
**Consequence:** This is a transparent initial heuristic, not a validated industry standard; test math and revisit after user feedback.

## D-010 — V1 non-goals
**Status:** Accepted  
**Decision:** Do not implement billing, team invitations, complex organization roles, live third-party review/helpdesk ingestion, automatic external actions, AutoScientist, automatic model promotion, or custom model fine-tuning during first public beta.  
**Reason:** Complete and verify the core workflow first.

## D-011 — Deployment claim discipline
**Status:** Accepted  
**Decision:** A feature is called live/verified only after a relevant end-to-end check on the actual deployed build or a clearly identified test environment.  
**Consequence:** README/status pages must distinguish planned, implemented-unverified, and implemented-verified states.

## Decision-change procedure

Create the next numbered entry, document why a change is necessary and the impact, update every dependent specification, and avoid leaving conflicting legacy statements in active instructions. Routine implementation details that do not change product/architecture decisions do not need a new entry.
