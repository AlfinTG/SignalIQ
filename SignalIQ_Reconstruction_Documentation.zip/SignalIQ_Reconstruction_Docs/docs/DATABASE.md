# Database and Persistence — SignalIQ

## Purpose

PostgreSQL is the durable source of truth for application data. Browser local storage may retain non-sensitive UI preferences, but it must not be the authoritative store for feedback, issue state, analysis provenance, verified training examples, or Adaption job history.

## Target ownership model

For the first public beta, each authenticated user owns one private workspace. Team membership and cross-user shared workspaces are deferred. Keep `workspace_id` on all workspace-owned entities so future sharing can be added deliberately. Resolve the workspace server-side from the verified user identity.

## Entities

### `workspaces`
- `id` UUID primary key.
- `owner_user_id` UUID corresponding to the authenticated Supabase user.
- `name`, `created_at`, `updated_at`.
- Optional settings with strict schema/size limits.

### `feedback_records`
- `id` UUID primary key; `workspace_id` foreign key.
- `text` original customer comment; `source`, `source_reference` if available.
- `submitted_at` nullable source date; `created_at`, `updated_at`.
- `rating` nullable numeric with range validation.
- `sentiment` (`positive`, `neutral`, `negative`, `unclassified`).
- `category`, normalized `issue_key`, `severity`, `confidence` nullable.
- `analysis_explanation`, `suggested_action`, `analysis_mode`, `model_name`, `analysis_version`, `analyzed_at`.
- `is_sample`, `import_batch_id`/source provenance where useful.

### `issue_states`
- `id`, `workspace_id`, normalized `issue_key`, `status` (`Open`, `In progress`, `Resolved`), optional notes, `created_at`, `updated_at`.
- Unique constraint for `(workspace_id, issue_key)`.
- Status changes should not delete source feedback or previous analysis results.

### `analysis_runs`
- `id`, `workspace_id`, `provider`, `model_name`, `mode`, `status`, requested/processed/failed counts, non-sensitive error code/summary, `started_at`, `finished_at`, `created_by`.
- Avoid storing raw sensitive provider payloads or secrets in logs/history.

### `training_examples`
- `id`, `workspace_id`, optional `source_feedback_id`, `instruction`, `input_text`, `target_output`.
- `label_status` such as `unreviewed`, `verified`, `rejected`; `verified_by`, `verified_at`, `created_at`, `updated_at`.
- Keep provenance showing whether an original label came from Gemini, rules-based demo analysis, a user correction, or synthetic data.
- Only eligible verified rows should be exported into a trusted adaptation dataset by default.

### `adaption_jobs`
- `id`, `workspace_id`, `created_by`, external `dataset_id`, external `run_id` nullable.
- `status`, `phase`, selected example count, requested row cap, estimated credits/minutes nullable, non-sensitive error summary, output format, `created_at`, `updated_at`, `finished_at`.
- Do not store provider API keys or raw secrets. Never treat external IDs as authorization; every lookup is scoped to the owner workspace.

### `report_runs` (optional if report history is implemented)
- `id`, `workspace_id`, `created_by`, scope/filter snapshot, data snapshot/version metadata, format, status, `created_at`.
- Avoid storing generated files containing customer text unless retention and access rules are explicit. Report generation may remain download-only in v1.

## Data constraints and indexes

- Add `workspace_id` and timestamp indexes to common list queries.
- Index `(workspace_id, submitted_at)`, `(workspace_id, sentiment)`, `(workspace_id, issue_key)`, and `(workspace_id, status)` where supported by real query patterns.
- Constrain ratings, enums/statuses, text lengths, and external IDs.
- Use stable UUIDs, parameterized queries/ORM operations, foreign keys, and transaction boundaries.
- Avoid a single huge JSON workspace blob; keep feedback and issue states queryable.
- Paginate API results and cap batch/import size.

## Authorization and RLS

FastAPI must verify the token, resolve the user's workspace, and scope every query by the resolved workspace. Never rely on frontend checks. Use least-privilege DB credentials. If using direct client data access or exposed Supabase tables, enable appropriate RLS and grants and test allow/deny cases. If server DB credentials bypass RLS, do not count RLS as protection for that server path; enforce and test authorization in FastAPI.

## Migration and data transition

Use repeatable schema migrations, preferably Alembic or an equivalent already-established migration tool. Test migrations against a fresh database and the target state. Do not automatically upload browser `localStorage` into the new database. If importing legacy local data is offered, require an explicit user-initiated, previewable, idempotent migration flow with duplicate handling.

## Retention and deletion

Define account/workspace deletion behavior, deletion of provider job metadata, and retention of exported files before launch. Never promise that provider-side datasets can be deleted unless the provider workflow supports and verifies it. Avoid storing personal data that the product does not need.
