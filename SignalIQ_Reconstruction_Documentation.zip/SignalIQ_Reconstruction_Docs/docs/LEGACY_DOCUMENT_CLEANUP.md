# Legacy Documentation Cleanup — Safe Replacement Plan

This guide is for the documentation-only checkpoint. It does not authorize deleting source code or reference assets.

## Keep as authoritative

- Root `AGENTS.md`
- Root `README.md`
- The active documents listed from `docs/PRD.md` through `docs/PHASE_EXECUTION_TEMPLATE.md`
- Existing `images/` assets, including the dashboard, feedback explorer, and insights/action reference screenshots
- All application source, package manifests, dependency lockfiles, tests, `.gitignore`, `.env.example`, and license unless individually audited and approved for change

## Supersede or archive after inspection

The current repository includes `docs_bundle/`, nested copies of an `InsightFlow_Cursor_Documentation_Bundle`, and `InsightFlow_Cursor_Documentation_Bundle.zip`. These older files contain prototype-era prompts, an alternate product name, a navy/blue visual direction, and instructions to keep browser-only persistence and avoid authentication/database work.

Before removing these from the active repository:
1. Search for any unique facts/assets not covered by the canonical documents.
2. Preserve anything useful outside the active instruction path if historical records are desired.
3. Ensure no current agent instruction links to or treats the old bundle as authoritative.
4. Remove or archive the outdated duplicate bundle in a deliberate cleanup commit.

Do not delete the `images/` directory or current frontend/backend source as part of documentation cleanup.

## Check for contradictions before committing

Search the active repository docs for stale phrases such as:
- `nine-hour` / `approximately nine hours`
- `do not add authentication`
- `do not introduce a database`
- `browser localStorage` described as the authoritative storage for the final service
- `navy sidebar` / `blue accent` as the approved final visual direction
- `InsightFlow` described as the active product name
- claims that Adaption output is already used for live classification

Historical audit sections may quote these phrases when explaining what changed, but they must clearly identify them as outdated instructions.

## Commit strategy

1. Commit documentation replacement and conflict cleanup separately from application-code reconstruction.
2. Review `git diff --check` and the complete diff.
3. Push the documentation checkpoint.
4. Start Phase 0/re-audit on the pushed revision before Phase 1 UI implementation.
