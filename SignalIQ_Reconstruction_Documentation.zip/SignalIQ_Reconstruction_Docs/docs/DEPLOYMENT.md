# Deployment — SignalIQ

## Status

This document defines the target deployment path. It does not assert that the app is deployed or that any host/provider configuration already exists.

## Target topology

- One web service for the built React/Vite frontend and FastAPI `/api/*` routes where practical.
- Managed Supabase Auth and PostgreSQL.
- Gemini and Adaption accessed only from the backend.
- Hosting provider must support the chosen Python runtime, build/start commands, environment secrets, outbound HTTPS, persistent logs, and health checks. Verify current provider requirements and plan limits before choosing it.

## Production settings

The exact final environment names must match the implementation. Expected categories:

**Application:**
- `APP_ENV=production`
- `PORT` provided by host
- `DATABASE_URL` (server secret)

**Auth:**
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY` for browser auth only if required by the selected SDK/configuration
- Backend JWT verification configuration such as issuer/JWKS URL only if not safely derived from the project URL

**AI providers:**
- `GEMINI_API_KEY`
- `GEMINI_MODEL`
- `ADAPTION_API_KEY`
- bounded row/time limits as implemented

Keep real secrets in host-managed environment/secret settings. `VITE_` values are bundled into public assets and are not a place for secrets. Only public/publishable browser configuration may use frontend environment variables. Update `.env.example` only when the code actually requires these variables.

## Build/start expectations

The current repository uses Vite and FastAPI and already contains a code path to serve `frontend/dist` if present. Confirm it still works after reconstruction. The target pipeline should:
1. Install pinned/locked frontend and backend dependencies.
2. Run typecheck, tests, and frontend production build.
3. Apply reviewed database migrations with a deliberate release step.
4. Start FastAPI using the host-assigned `PORT` and listen on `0.0.0.0`.
5. Serve assets and API paths without conflicting fallback routes.
6. Expose a health check that confirms application liveness and, where useful, non-sensitive dependency status without returning credential material.

Do not use development reload mode in production. Do not assume that a host's free tier, sleeping behavior, build minutes, outbound network, or persistence guarantees remain unchanged; verify current policies at deployment time.

## Database release process

- Use migrations tracked in the repository.
- Test the migration on a clean database and a representative upgrade path.
- Back up data before destructive schema changes.
- Ensure runtime credentials follow least privilege.
- Test actual authorization/query behavior with production-equivalent roles; do not rely on RLS assumptions that differ from the deployed database connection.

## Release smoke checks

After each deployment verify:
- Public URL uses HTTPS and frontend assets load.
- Sign-up/sign-in/logout/session refresh work.
- Authenticated API rejects missing/invalid/expired credentials.
- Two accounts cannot access one another's data.
- Feedback add/import, analysis, issue tracking, and export complete successfully.
- Data survives page refresh and service restart.
- Gemini missing-key, timeout/rate-limit, and malformed-result states are handled without fabricated output.
- Adaption configuration state, estimate, explicit confirmation, actual status and download work when access/credits are available.
- Mobile layout and critical controls work.
- Logs contain no secrets or unnecessary raw customer text.

Record the deployed URL, commit SHA, migration state, exact smoke tests performed, and unresolved issues. Only claim a feature is deployed when checked on the real deployment.
