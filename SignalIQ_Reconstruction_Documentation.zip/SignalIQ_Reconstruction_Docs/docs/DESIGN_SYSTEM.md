# Design System — SignalIQ

## Design intent

SignalIQ should feel like a thoughtful analytical workbench with an editorial sensibility. It should not look like the default navy-sidebar/bright-blue AI SaaS template. Use warm neutrals, natural greens, restrained warm accents, expressive but readable typography, and dense-but-breathable data layouts.

## Color tokens

Use semantic tokens rather than scattering hex values through components. The following palette is a starting point; validate contrast and hierarchy during Phase 1.

| Token | Suggested value | Use |
|---|---|---|
| `canvas` | `#F5F3EC` | Main warm page background |
| `surface` | `#FFFEFA` | Main content surfaces |
| `surface-raised` | `#FFFFFF` | Dialogs, menus, high-focus panels |
| `surface-muted` | `#EDEAE1` | Muted sections and table headers |
| `text-primary` | `#252B27` | Main text |
| `text-secondary` | `#626B63` | Descriptions and metadata |
| `text-tertiary` | `#7A817A` | Lower-priority metadata, after contrast check |
| `border` | `#DEDCD2` | Fine separators and input borders |
| `brand-forest` | `#315D4C` | Primary brand action and key data series |
| `brand-sage` | `#DDE8DD` | Soft highlight surfaces |
| `accent-terracotta` | `#B96D4D` | Selective emphasis, never all buttons |
| `accent-amber` | `#B98232` | Caution and secondary emphasis |
| `positive` | `#34745A` | Positive status |
| `warning` | `#94661D` | Warning status |
| `negative` | `#B34D45` | Negative status/errors |
| `focus-ring` | `#477B68` | Visible keyboard focus |

Do not convey sentiment, priority, or status through color alone. Pair color with labels, icons, shapes, or text. Verify text contrast for actual text sizes before finalizing tokens.

## Typography

- Use a distinctive editorial face for major page headings and a highly readable sans-serif for UI, tables, controls, and dense data.
- Prefer a small, deliberate type scale over many arbitrary sizes.
- Headlines should be confident, not oversized marketing typography inside the app.
- Avoid low-contrast thin fonts for tables and metrics.
- Use tabular numerals for comparable KPI values when supported.

## Layout and spacing

- Use an 8px base rhythm where practical, with consistent 4px fine adjustments.
- Choose a stable content max-width and responsive page gutters.
- Use a persistent but visually quiet navigation rail on desktop; use a proper mobile drawer or bottom/navigation pattern after testing the reference layouts.
- Vary page composition where it clarifies intent: KPI strip, one primary chart, issue list, details panel, or editorial insight section. Avoid placing every element in an identical rounded card.
- Use borders and whitespace before adding shadows. Shadows should be subtle and rare.
- Prefer moderate corner radii and crisp boundaries; avoid over-rounding every element.

## Components

Standardize buttons, inputs, selects, date filters, badges, tables, charts, pagination, empty states, confirmation dialogs, toasts, banners, and loading placeholders. Define primary, secondary, tertiary, destructive, and disabled button states. Every component must have keyboard focus and error/disabled behavior.

## Data visualization

- Use a consistent palette, restrained gridlines, labelled axes, clear units, and accessible tooltips.
- Include a legend/text description when needed; never rely on hover as the only way to learn a value.
- Don't imply a continuous trend when dates are missing or insufficient.
- Use matching date scopes across related KPIs and charts.
- Show negative/positive categories with both color and text/labels.
- Use charts to answer a business question, not merely fill empty space.

## Iconography and assets

Use the installed Lucide icons consistently. Avoid mixing multiple icon families or using emoji as primary navigation icons. Use genuine supplied assets and screenshot references where relevant. No decorative stock photos are required for the analytics workspace.

## Motion

Keep interactions fast and restrained: brief transitions for menus, tabs, and progress feedback. Respect `prefers-reduced-motion`. Never animate KPI numbers in a way that obscures their value or implies live data when it is not live.

## Do not

- Reintroduce a dominant navy sidebar with bright blue as the universal accent.
- Use giant gradient hero blocks inside core product pages.
- Build every section as a matching grid of generic statistic cards.
- Use fake charts, decorative buttons, fabricated AI confidence, or hardcoded live-looking totals.
- use color alone to communicate a category or status.
