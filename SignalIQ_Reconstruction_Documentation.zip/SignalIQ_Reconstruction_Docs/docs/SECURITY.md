# Security Requirements — SignalIQ

## Baseline

The existing repository is an unauthenticated prototype. The rebuilt public service must not treat prototype security as adequate. This document defines target controls; implementation and verification are tracked by phase.

## Identity and authorization

- Use Supabase Auth for user identity/session support in the target architecture.
- FastAPI verifies access-token signature and required issuer/audience/expiry claims using a supported maintained library/provider mechanism. Never trust decoded-but-unverified JWT payloads.
- Resolve the user's private workspace from verified identity. Do not authorize based on user IDs or workspace IDs supplied in request bodies, query strings, headers, or frontend state.
- Every list/read/write/import/export/analysis/Adaption-job operation must check ownership server-side.
- Use generic authentication failures where revealing resource existence would leak information.
- Add tests with two users proving that a user cannot read, edit, delete, export, analyze, or download another user's records/jobs.

## Database controls

- Use least-privilege database credentials and parameterized/ORM queries.
- Use migrations, foreign keys, size constraints, appropriate indexes and transaction boundaries.
- Scope database queries by the authenticated workspace.
- If Supabase tables are exposed to browser data access, enable Row Level Security and explicit grants/policies for each operation and test allow/deny behavior. Do not rely on RLS if the actual connection role bypasses it; test the real deployment path.
- Never expose the database password or service-role/secret key to browser code.

## Secrets and configuration

- Secrets include database URL/password, Gemini key, Adaption key, JWT-related private secrets, and privileged service keys.
- Store secrets only in local ignored environment files for development and the hosting provider's secret manager/environment configuration in production.
- Never use a `VITE_` prefix for a secret. Browser-published auth keys are only acceptable when explicitly designed as publishable keys and paired with correct access controls.
- `.env.example` contains variable names and safe placeholders only.
- Do not print secrets, authorization headers, complete environment values, or provider request dumps in logs/errors.
- Rotate any credential accidentally committed or exposed; deleting the committed line does not revoke it.

## Input and output safety

- Validate and limit comment length, upload size, row count, column count, rating, date, and allowed enum values.
- Treat CSV text, labels, model output, imported filenames, and generated report values as untrusted.
- Protect CSV exports against spreadsheet formula injection (for example cells beginning with formula-triggering characters) and escape content in HTML reports.
- Never evaluate imported strings or render untrusted HTML directly.
- Restrict uploaded file types based on actual parsed content, not the extension alone.
- Prevent path traversal and unsafe temporary-file handling; clean temporary files reliably.

## Privacy and AI-provider handling

- Collect only data needed for the product.
- Tell users when selected feedback/dataset content will be sent to Gemini or Adaption.
- Use narrow request payloads and redact obvious identifiers when appropriate. Regex redaction is not a guarantee of anonymization.
- Do not include real customer feedback in fixtures, screenshots, tests, logs, or public issue reports.
- Define data deletion/retention before release and avoid promising deletion from external providers unless verified.

## Abuse and availability

- Apply request timeouts, batch limits, rate limits and upload limits, especially on AI and Adaption endpoints.
- Do not auto-trigger a potentially credit-consuming Adaption run. Require an estimate and separate confirmation; prevent duplicate submissions with idempotency/state checks.
- Handle expired auth sessions, revoked access, provider rate limits, timeouts, and partial failures.
- Return safe error summaries with request/correlation IDs where useful; never leak stack traces to users.
- Monitor errors and resource use without logging secrets or unnecessary personal data.

## Release security gate

Release is blocked by any known cross-account data leak, exposed secret, unauthenticated private route, untested import/export injection risk, or provider workflow that bypasses explicit user consent. Record test evidence rather than merely asserting that security is implemented.
