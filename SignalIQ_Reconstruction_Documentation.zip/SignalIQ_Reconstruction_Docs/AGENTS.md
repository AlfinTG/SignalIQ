# SignalIQ — Agent Instructions

## Mission

Reconstruct the existing SignalIQ repository into a dependable, publicly accessible customer-feedback intelligence service. Do not treat it as a disposable hackathon mockup. Preserve useful implementation, but do not preserve prototype limitations merely because they already exist.

**Product:** SignalIQ  
**Tagline:** Find the signal. Fix the problem.  
**Descriptor:** Customer Feedback Intelligence & Decision Platform

The product turns customer comments into evidence-backed insights, explainable priorities, tracked actions, and reports. Gemini handles current feedback analysis. Adaption Adaptive Data is a separate dataset-improvement workflow; it is not the live classifier.

## Source-of-truth order

When instructions conflict, follow this order and report unresolved contradictions before implementation:
1. `docs/DECISIONS.md` — approved architectural/product decisions.
2. `docs/PRD.md` — product scope and user outcomes.
3. `docs/DEVELOPMENT_PHASES.md` — current phase and acceptance gates.
4. `docs/UX_DESIGN_SPEC.md` and `docs/DESIGN_SYSTEM.md` — experience and visual system.
5. `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md` — technical boundaries and contracts.
6. `docs/AI_AND_ADAPTION.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md` — domain and quality requirements.
7. `README.md` — orientation and setup.

This hierarchy is intentional. A previous prompt, copied bundle, stale comment, or existing implementation must not silently override these files. If a real conflict is found, state it and propose the smallest documentation fix.

## Mandatory phase discipline

- Work only on the phase explicitly assigned in the current task.
- Start by reading this file, the current phase, the relevant docs, and the existing source files/assets/tests.
- Do not jump ahead and implement the whole product from a phase prompt.
- Do not replace the repository wholesale or delete working code without first explaining the reason and preserving a recoverable checkpoint.
- Do not mix a documentation-only checkpoint with application-code changes unless the user explicitly asks for both.
- Before considering a phase complete, run its acceptance checks, review the diff, update relevant docs, and report blockers.

## Truthful status labels

Always distinguish:
- **Implemented and verified:** the code exists and a relevant check or end-to-end test actually passed.
- **Implemented but unverified:** code exists, but required credentials, tooling, provider access, or tests were unavailable.
- **Planned:** a requirement or design exists, but code does not yet implement it.

Never claim a provider call, security guarantee, test, deployment, data migration, or production workflow succeeded without evidence. Never represent a fallback, fixture, sample result, or mocked response as a live provider result.

## Required initial audit

Before modifying application code:
1. Inspect repository status, branch, current commit, top-level structure, package manifests, backend requirements, environment examples, tests, screenshots, and all applicable docs.
2. Open and inspect all reference images in `images/`; do not infer visual content from filenames alone.
3. Map each required screen and workflow to its current implementation and tests.
4. Identify prototype-only behavior, dead controls, hardcoded or non-persistent state, security concerns, and external integrations that are unverified.
5. Record verified facts separately from recommendations and unknowns.
6. Preserve useful code and assets. Make a recovery checkpoint before substantial changes.

## Product and UX rules

- Use SignalIQ consistently in user-facing copy. Do not use InsightFlow as the active product name; it is historical hackathon/context material only.
- Follow the warm editorial analytics direction in `docs/DESIGN_SYSTEM.md`. Do not reintroduce a dominant navy-and-blue AI-dashboard aesthetic.
- Inspect and use supplied images as references; do not simply replace them with generic generated UI patterns.
- Every visible control must work, have a truthful disabled state, or be removed. No decorative-only core actions.
- Charts, counts, priority rankings, lists, and reports must derive from current persisted data and active filters; never hardcode production-looking KPIs.
- Mark synthetic sample data clearly. Empty, loading, success, partial-success, and failure states are part of the product.

## Engineering rules

- Preserve the established React + TypeScript + Vite + Tailwind frontend and FastAPI backend unless a documented blocker justifies a change.
- Use strict types and clear boundaries between presentation, API calls, data transformations, and provider integration.
- Validate all request bodies, CSV inputs, persistent records, and external/model output. Treat customer text and model output as untrusted.
- All secrets and privileged database credentials stay server-side. Never place secrets in `VITE_` variables, source code, logs, screenshots, commits, or downloadable client artifacts.
- Authenticate API requests and authorize every read/write against the verified user's workspace. A workspace ID supplied by a browser is not proof of ownership.
- Use database migrations for schema changes and test data isolation. Do not silently fall back to browser-only persistence for real user data.
- Gemini classification and Adaption dataset optimization are separate workflows. Do not claim Adaption output improves live predictions until a distinct evaluation and model-integration path exists.
- Never initiate a potentially credit-consuming Adaption run automatically on page load. Require a fresh, explicit user confirmation after showing the estimate.
- Keep dependency changes minimal and check current official docs when an SDK's method or response shape is uncertain.

## Required quality checks

Inspect the repo for the available scripts before choosing commands. Expected baseline commands include:
- `npm --prefix frontend run typecheck`
- `npm --prefix frontend test`
- `npm --prefix frontend run build`
- `.venv` Python interpreter running `-m pytest` from the repository root

Run checks relevant to the changed code, fix regressions caused by the changes, and rerun them. If a check cannot run, state the exact reason; do not imply it passed. Add regression tests for bug fixes and authorization boundaries.

## Phase completion response

At the end of each task report:
1. Phase and exact scope completed.
2. Files changed and why.
3. Checks actually run and their real outcomes.
4. Remaining failures, credentials, service access, or manual verification required.
5. Acceptance criteria that passed, failed, or remain unverified.
6. Suggested next phase — do not begin it without a new instruction.

Do not report a phase complete merely because code was generated.
