# CODEX MASTER PROMPT — PHASE 0: REPOSITORY AUDIT & RECONSTRUCTION BASELINE

You are working inside the existing **SignalIQ** repository. This is Phase 0 of a controlled reconstruction—not permission to rebuild the whole application in one pass.

## Mission

Establish an accurate, repository-grounded view of the current codebase and verify that the new canonical documentation is present and internally consistent before any substantial application changes. We have already prepared and copied the reconstruction documentation; do not repeat the previous prototype build instructions or blindly regenerate the documentation bundle.

**Product identity:** SignalIQ — “Find the signal. Fix the problem.”  
**Product purpose:** turn customer feedback into traceable insights, explainable priorities, tracked actions, and reports.  
**Target:** a usable public-beta service, not a throwaway hackathon mockup.

## Required source-of-truth files

Read these before investigating or changing anything:

- `AGENTS.md`
- `README.md`
- `docs/DECISIONS.md`
- `docs/PRD.md`
- `docs/DEVELOPMENT_PHASES.md`
- `docs/UX_DESIGN_SPEC.md`
- `docs/DESIGN_SYSTEM.md`
- `docs/ARCHITECTURE.md`
- `docs/DATABASE.md`
- `docs/API_CONTRACTS.md`
- `docs/AI_AND_ADAPTION.md`
- `docs/SECURITY.md`
- `docs/TESTING.md`
- `docs/DEPLOYMENT.md`

If a file is missing, note it and create only the minimum canonical file needed; do not invent implementation facts.

## Task A — Establish the exact repository state

1. Inspect the current branch, current commit, working-tree changes, top-level folders, tracked assets, package manifests, backend requirements, environment examples, `.gitignore`, and existing deployment configuration.
2. Do not discard, reset, clean, stash, overwrite, or rebase the user's working tree. Do not perform destructive Git commands.
3. Inspect the actual frontend entry point, routing, shell, page components, state/persistence layer, API client, and data transformation functions.
4. Inspect the FastAPI entry point, routes, schemas, configuration, Gemini integration, Adaption integration, error handling, and job lifecycle.
5. Inspect the existing tests and available scripts. You may run quick read-only inspection commands. Do not conduct a full regression suite in this phase unless a very small check is needed to establish a baseline.
6. Open and visually inspect all images under `images/`, including `Dashboard reference.png`, `Feedback Explorer reference.png`, and `Insights and Actions reference.png`. Do not infer screenshot details from filenames alone. Describe their layout, hierarchy, color, density, typography, charts, and interactions as far as the screenshots support.
7. Inspect all additional relevant screenshots/images that are already in the repository and identify whether each is a desired reference, an old output, or unclear.
8. Search for outdated copied prompt bundles or documents, especially `docs_bundle/`, any ZIP containing old instructions, and duplicate `AGENTS.md` files. Do not delete anything yet. Identify conflicting sources and whether unique useful material needs preserving.

## Task B — Create a factual current-state map

Update `docs/CURRENT_STATE_AUDIT.md` with:

- Date/time of the audit and the exact checked-out commit SHA/branch.
- Repository tree summary and actual stack/dependency facts.
- Screenshot findings based on the actual image pixels.
- Each major feature's status using only these labels:
  - **Implemented and verified** — source exists and a relevant check was actually performed successfully.
  - **Implemented but unverified** — relevant source exists but runtime/credential/deployment behavior was not proven.
  - **Planned** — documented target behavior is not implemented yet.
- A map of relevant source files for the frontend shell/routes, feedback state, import/export, charts/metrics, Gemini, Adaption, persistence, authentication, database, tests, and deployment.
- Current behavior and gaps, with evidence in paths/function names where practical.
- Existing useful code to preserve and code likely requiring replacement.
- Known blockers, environmental limitations, credentials unavailable, and checks not performed.

Specifically investigate and report the current status of browser `localStorage`, account/auth flows, server-side database persistence, workspace isolation, Gemini live analysis, rule-based fallback, priority-score implementation, Adaption dataset creation, human verification of labels, confirmation before potentially billable runs, Adaption job persistence, report/export flows, and deployment. Existing source code is not proof a live provider or deployment works.

## Task C — Reconcile documentation, but do not redesign it here

- Confirm that the canonical documents agree about the product name, scope, stack, phases, visual design, authentication/persistence, and Adaption's role.
- The active name is **SignalIQ**. `InsightFlow` may be mentioned only as historical context.
- Target visual direction is **warm editorial analytics**: warm ivory/stone, charcoal, muted forest/sage green, restrained terracotta/amber, thoughtful typography, and no dominant navy-and-blue AI-template look.
- Target architecture retains React + TypeScript + Vite + Tailwind on the frontend and FastAPI/Pydantic on the backend unless a real blocker is discovered. Supabase Auth + PostgreSQL are the accepted target direction; verify exact integration details in the implementation phase using official current documentation.
- Gemini is the current live-analysis provider. Adaption is a separate training-data optimization workflow and must not be presented as the current live classifier.
- Fix a documentation contradiction only if the repository gives clear evidence. Update all dependent docs consistently and record material decisions in `docs/DECISIONS.md`.
- Do not add features to the product scope and do not rewrite the app during this task.

## Explicitly out of scope

- Do not implement authentication, database migrations, new API endpoints, or redesigned application screens.
- Do not create a new repository or replace the stack.
- Do not run broad UI changes.
- Do not delete old prompt bundles or other potentially useful assets until their unique content has been reviewed and a cleanup step is explicitly assigned.
- Do not claim tests, real Gemini/Adaption calls, database access, or deployment are verified without evidence.

## Completion requirements

1. Update `docs/CURRENT_STATE_AUDIT.md` with factual local-repository findings.
2. If canonical docs were missing or demonstrably contradictory, make only the narrow necessary corrections and list every changed document.
3. Provide a concise phase report: inspected paths, exact commands/checks performed and outcomes, implemented/verified vs unverified vs planned findings, reference-image observations, blockers, and recommended next phase.
4. Do not commit or push; the user will review and push the phase changes.

Suggested commit message: `docs: audit SignalIQ reconstruction baseline`
