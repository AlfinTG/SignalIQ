# CODEX MASTER PROMPT — PHASE 5: COMPLETE FEEDBACK WORKFLOWS, REPORTS & ADAPTION

Complete SignalIQ's end-to-end customer-feedback journey on the real authenticated APIs and persisted data. This phase integrates the frontend, database, analysis engine, reporting, and Adaption workflow. Do not convert any workflow to a fake success or in-memory-only feature.

## Read first

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/UX_DESIGN_SPEC.md`, `docs/API_CONTRACTS.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/AI_AND_ADAPTION.md`, `docs/SECURITY.md`, and `docs/TESTING.md`. Inspect actual Phase 2–4 code, migration state, current frontend API adapters, Gemini outputs/provenance, CSV utilities, report utilities, and Adaption SDK code. Reuse rather than duplicate existing good functionality.

## Core acceptance journey

A signed-in user must be able to:

1. Add a feedback comment or import a CSV.
2. Preview/map/validate the input and see accepted/rejected row counts.
3. Persist the records into their private workspace.
4. Run live Gemini analysis where configured, or consciously select a clearly labeled available demo flow.
5. See analysis saved to the correct records with provenance/status.
6. Filter feedback and see matching counts/charts/issue groups.
7. Open an issue, inspect actual supporting feedback, and understand its priority breakdown.
8. Change issue status, refresh, and confirm the state persisted.
9. Export a report and compare its numbers/evidence with the selected data.
10. Review/correct labels and select only explicitly verified examples for Adaption.
11. Preview and export the training dataset, estimate a real Adaption job, explicitly confirm a run, monitor actual provider status, and download actual output only when ready.

## Task 1 — Finish feedback CRUD, import and consistent filters

- Wire add/edit/delete, search, sorting, filtering, pagination and record detail to authenticated persistent APIs.
- Make CSV import resilient and transparent. Support common aliases for comment text, date, rating, and source. Show sample preview and candidate mappings; request correction if ambiguous. Handle Unicode/encoding, BOM where applicable, commas, quotes, blank rows, malformed values, oversized files, duplicates/retries and row limits.
- Report imported/accepted/rejected row counts and useful row-level failure reasons. Never silently discard rows.
- Avoid partial duplicated writes after retries; use idempotency or stable duplicate-detection policy documented in the product.
- Ensure imported records belong to the authenticated user's workspace. Never permit an upload to select another user's workspace by a client ID.
- Make all main-page metrics, charts, issues, and exports agree with the same selected workspace/filter/date scope.

## Task 2 — Finish priorities and action tracking

- Show stable issue grouping, actual support count and example excerpts/links, sentiment mix, severity information, date coverage, trend only when enough data exists, and an explainable priority score.
- Follow the weighting and missing-trend behavior in `docs/DECISIONS.md`; do not invent a trend if the dataset cannot support it.
- Tie suggested next actions to observed feedback and keep them concise and reviewable.
- Persist `Open`, `In progress`, and `Resolved` states and reflect changes across dashboard, issue pages, and reports.
- Maintain a useful status history/timestamp if included in the agreed data model; do not delete evidence when an issue resolves.

## Task 3 — Deliver accurate reporting and exports

- Implement the documented downloadable report format(s), CSV export, and print/download flow where specified.
- Include report scope, selected date range, dataset size, data coverage, KPI definitions, top issues, priority component breakdown, recommendations, and traceable evidence where appropriate.
- Derive every number from the authorized selected data. Include limitations for missing dates, incomplete analysis, synthetic sample data, and unavailable trend.
- Escape user-provided feedback safely in HTML. Prevent spreadsheet formula injection in CSV exports. Do not execute or trust imported cell content.
- Avoid rendering arbitrary raw HTML from comments or model output.
- Ensure only the authorized owner can generate/download a report from their private data.

## Task 4 — Build a reviewable Adaption dataset workflow

Adaption is **not the live classifier**. It is a separate workflow to prepare/optimize a task-specific dataset for downstream model development. Do not claim that the resulting data automatically changes Gemini's predictions.

Implement these steps with accurate states:

### A. Prepare and curate examples
- Select only explicitly reviewed/verified records by default.
- Display why each example is eligible/ineligible and preserve source-record IDs/provenance without needlessly exposing personal data in exported files.
- Let a user inspect/correct targets and select a bounded set of examples.
- Show input/output schema and column mapping preview; reject empty or structurally invalid examples.
- Allow downloading the source CSV before provider upload.
- Clearly explain what data will be sent to Adaption and require deliberate user action to upload/run.

### B. Estimate
- Use the current supported official Adaption Python SDK. Verify package/API method names and response shapes against current official Adaption documentation rather than assuming old shapes remain valid.
- Upload the prepared supported dataset, wait for provider ingestion/status, and request `estimate=True` using the correct column mappings for actual CSV headers.
- Display only estimates/IDs/status returned by the provider. Never invent a cost, duration, dataset ID, or success response.
- Treat estimates and runs as separate API operations.

### C. Explicit confirmation and run
- After showing the estimate, require a fresh, explicit confirmation before starting any operation that may consume credits.
- The server must enforce confirmation; hiding/greying the frontend button is not the only control.
- Never start or resume a billable run merely by opening a page, reloading, polling, or retrying a GET request.
- Prevent accidental duplicate submission with an idempotent or clearly recoverable run state.

### D. Persist job history and ownership
- Store the application job metadata in PostgreSQL, including owner/workspace, provider dataset/run IDs, phase/status, estimates returned, timestamps, progress, safe error details, and output availability.
- Replace in-memory-only job storage as the authority. A server restart must not erase SignalIQ's knowledge of created jobs.
- Re-check authorization on every estimate/run/status/download endpoint. Never expose another user's provider dataset or job by guessing a job ID.
- Where possible, recover status using persisted provider identifiers after restart. If the provider state can no longer be recovered, show an honest recovery/error state.
- Do not store provider secrets in job rows.

### E. Status and output
- Poll through a bounded, backoff-aware strategy or documented asynchronous mechanism; stop polling on terminal states and handle network failure.
- Map provider-reported success/failure/status values correctly according to current SDK docs. Unknown states are not success.
- Enable download only when provider output is actually available. Download the actual output, report failures, and clean temporary files.
- Clearly state that output is a dataset for downstream model development, not proof of a trained or evaluated model.
- When credentials are missing, implement a clear unavailable/configuration state without simulating a successful job.

## Task 5 — Reliability and interaction details

- Check loading, empty, partial-success, retry, validation failure, session expiry, permission denial, timeout, missing-key, provider failure, and download-not-ready states.
- Keep user-facing language clear and informative. No dead buttons or decorative “working” progress bars.
- Do not log raw comments, auth tokens, dataset content, or secrets unnecessarily.
- Apply sensible file, row, text, response-size, and processing-time limits.

## Constraints

- Do not add automatic external actions, billing, live ingestion integrations, team collaboration, AutoScientist or automatic model promotion.
- Do not remove a working feature just because integration takes effort; reuse existing importer/report/provider code where safe.
- Do not fake successful requests when credentials are unavailable.

## Focused checks and handoff

Test the changed boundaries where practical: import validation, score/report consistency, owner-scoped resources, Adaption confirmation enforcement, job persistence, provider-state mapping, and download readiness. Do not run the entire final release suite yet; Phase 6 is the comprehensive testing/release gate. Report every skipped check accurately.

Provide a final phase summary mapped to the ten-step core journey above and explicitly state which steps are implemented and verified, implemented but unverified, or still planned. Do not commit/push; the user will do so.

Suggested commit message: `feat: complete SignalIQ feedback and adaptation workflows`
