# SignalIQ — Codex Phase Prompt Pack

These prompts are intended to be pasted into Codex **one at a time**, in order. The user reviews each phase, pushes the resulting changes to Git, then starts the next prompt.

## Prompt order

1. `PROMPT_PHASE_0_AUDIT.md` — repo audit and factual baseline; no broad code changes.
2. `PROMPT_PHASE_1_UX_DESIGN.md` — lock the product UX and visual system using the actual reference screenshots.
3. `PROMPT_PHASE_2_FRONTEND.md` — rebuild the frontend and establish typed API boundaries.
4. `PROMPT_PHASE_3_AUTH_DATABASE_API.md` — add Supabase Auth, PostgreSQL persistence and ownership-scoped FastAPI endpoints.
5. `PROMPT_PHASE_4_AI_ENGINE.md` — harden Gemini analysis, provenance, issue aggregation and scoring.
6. `PROMPT_PHASE_5_WORKFLOWS_ADAPTION.md` — complete feedback workflows, reports, verified training examples and Adaption operations.
7. `PROMPT_PHASE_6_QA_DEPLOYMENT.md` — run comprehensive testing, security review and deployment verification.

## How to use

- Open the existing `SignalIQ` repository in Codex.
- Paste the complete contents of the next prompt file as one task. Do not paste multiple phase prompts together.
- Let Codex finish and read its phase report. Inspect the Git diff, then commit/push the phase yourself. Start the next phase only after reviewing the handoff.
- Use the commit message suggested at the end of each prompt as a starting point; adjust it to the real changes.
- Do not ask Codex to run destructive Git commands, wipe the project, publish credentials, or claim unverified integration/deployment success.

## Testing cadence

Phases 0–5 request focused checks relevant to current changes, not the entire release test cycle each time. Minimal checks are still important to avoid knowingly compounding missing imports, broken migrations, or broken integration contracts. Phase 6 is the comprehensive final test/release gate. Codex must always report exact checks run and not imply unrun tests passed.

## Non-negotiable product facts

- Product name: **SignalIQ**. `InsightFlow` is historical context only.
- Target: usable public-beta service, not the old nine-hour prototype.
- Frontend: retain React + TypeScript + Vite + Tailwind where practical; backend: FastAPI/Pydantic.
- Accepted target for identity/data: Supabase Auth + PostgreSQL, with verified auth and server-enforced workspace ownership.
- UI direction: warm editorial analytics; no dominant navy/blue AI-dashboard theme.
- Gemini handles live feedback analysis. Adaption Adaptive Data is separate dataset optimization—not the live classifier.
- Only explicitly reviewed/verified labels are eligible for the trusted Adaption training dataset by default.
- Never pretend a fallback, sample record, mock response, unverified provider call or untested deployment is real success.
- Do not commit/push automatically; the user handles the Git push after each phase.
