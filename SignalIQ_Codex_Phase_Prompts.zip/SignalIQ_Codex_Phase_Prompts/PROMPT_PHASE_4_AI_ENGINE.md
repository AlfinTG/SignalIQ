# CODEX MASTER PROMPT — PHASE 4: GEMINI ANALYSIS & EXPLAINABLE INSIGHTS

Implement SignalIQ's real, persistent AI-analysis workflow on top of the authenticated API and database created in Phase 3. Focus on safe analysis, accurate provenance, explainable issue aggregation, and persistence. Do not redesign the whole frontend or implement Adaption's full operations in this phase.

## Read first

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/API_CONTRACTS.md`, `docs/AI_AND_ADAPTION.md`, `docs/DATABASE.md`, `docs/SECURITY.md`, `docs/TESTING.md`, and `docs/UX_DESIGN_SPEC.md`. Inspect the current Gemini client, FastAPI analysis route, Pydantic schemas, frontend analysis adapter, data model, persistent tables, and tests. Preserve useful provider code after verifying it.

## Non-negotiable product rule

Gemini analyzes current customer feedback. Deterministic application code aggregates data, groups issues, calculates metrics and priority scores, and ensures that evidence links are accurate. Adaption is a separate training-data optimization workflow and is not the live classifier.

Never fabricate a label, reason, score, trend, provider result, or successful call when a request fails. Never label rule-based output as live Gemini analysis.

## Task 1 — Define the analysis contract

Implement/align a validated request and response contract that supports:

- Stable feedback record IDs and bounded comment text.
- Sentiment: positive, neutral, negative, or an explicit unclassified/failure state where the schema requires it.
- Consistent category and normalized issue key.
- Severity: low, medium, high, with unknown/not-yet-reviewed handled outside a forced AI assertion if necessary.
- Concise summary/explanation grounded only in the feedback.
- Optional model confidence only when the model/protocol meaningfully supplies it; do not present uncalibrated confidence as a probability of truth.
- Analysis mode/provider/model/version, timestamps, run ID, and per-record status/provenance as appropriate.
- Optional suggested action that must be supported by the observed feedback and should remain reviewable by the user.

Validate every model response. Reject malformed records, unexpected IDs, duplicate IDs, missing required fields, unsupported enum values, excessive lengths, and ungrounded data fields as far as practical. Do not trust LLM-produced totals or computed metrics.

## Task 2 — Harden live Gemini calls

- Keep API keys server-side.
- Use the current supported Google Gen AI SDK/provider call structure in this repository; verify uncertain behavior against current official documentation.
- Use bounded batches, explicit timeouts, configured model selection, and clear handling for missing key, authentication failure, rate limit, timeout, provider outage, invalid response, and partial per-record result failure.
- Prevent a failed or partially malformed run from wiping valid prior analysis. Persist successful valid rows transactionally, preserve failures and retryability, and disclose partial completion.
- Avoid sending direct identifiers/sensitive content to external providers when possible. Apply documented redaction and remind users that basic redaction is not anonymization.
- Do not log full raw feedback or secrets by default.
- Use idempotent run/job handling or a documented retry key so refresh/retry does not create uncontrolled duplicate analysis.
- Make cancellation/retry behavior explicit if implemented; do not expose pretend controls.

## Task 3 — Keep demo analysis honest

- Preserve a deterministic, testable demo/rules fallback only for deliberate demo mode or a clearly handled missing-provider scenario consistent with product docs.
- Clearly label `live-ai`, `demo-rules`, `unclassified`, and `failed` states in UI and stored data.
- Do not silently convert provider failure into an apparently successful live result.
- Do not overwrite a valid live classification with a demo result without deliberate user action.
- Provide useful error messages and recovery options while retaining source feedback.

## Task 4 — Build a deterministic insight and priority engine

In application code—not inside LLM counting—calculate aggregates from authorized persisted records and active filter scope. Follow `docs/DECISIONS.md`:

- Initial weight: frequency 40%, negative sentiment share 30%, trend 20%, severity 10%.
- Normalize available components to 0–100 and document definitions and bounds.
- Only calculate trend with adequate date coverage and a clearly stated comparison method.
- When trend is unavailable, redistribute its weight proportionally across available components and explicitly mark trend as unavailable.
- Handle zero records, missing dates, mixed date coverage, timezone boundaries, duplicate feedback, and small denominators safely.
- Keep grouping keys normalized and stable. Avoid accidental merging of distinct issues based only on similar phrases unless supported by a deterministic documented method.
- Ensure the frontend/report can show score components and relevant supporting feedback IDs/excerpts.
- Recommendations must be tied to actual issue evidence. Use reviewed structured AI output with strict validation or deterministic, documented category-based rules. Do not write generic advice and falsely claim it follows from unseen evidence.

## Task 5 — Human review and label provenance

Implement the data/service support needed for users to review and correct sentiment/category/severity/summary, if not already built. Track at minimum whether a value came from live AI, demo rules, or human correction/review, with timestamps and a review state. Keep source analysis history/provenance understandable; a correction should not make the original provider result indistinguishable from the reviewed version.

Only explicitly reviewed/verified examples may qualify for the trusted Adaption dataset in Phase 5. Do not mark an AI or rules label as verified automatically.

## Task 6 — Connect frontend states to the real analysis APIs

- Wire the UI to persistent analysis endpoints.
- Show progress, successful rows, failed rows, provider mode, and actionable error/retry states.
- Recalculate KPIs, charts, issue groups, and priority order from saved results and the same active filter scope.
- Handle session expiry and permission errors without leaking one user's data.
- Preserve a usable experience when Gemini is not configured, but disclose the mode and limitations.

## Constraints

- Do not claim analysis is clinically/financially validated or that the priority weights are an industry standard.
- Do not integrate an adapted model into live inference.
- Do not implement Adaption run lifecycle in this phase except the reviewed-label/verified-example foundation.
- Do not add unrelated external review sources, billing, or team features.

## Focused checks and handoff

Do targeted checks around Pydantic validation, provider failure handling, persistence and priority calculations as practical. Full suite and end-to-end validation are reserved for Phase 6. Note tests not run and never claim live Gemini verified if credentials/provider access are unavailable.

Report data contract, model/provenance behavior, issue-scoring rules, changes to frontend/API/database, focused checks, provider limitations, and suggested next step. Do not commit/push; the user will do so.

Suggested commit message: `feat: add explainable Gemini feedback analysis`
