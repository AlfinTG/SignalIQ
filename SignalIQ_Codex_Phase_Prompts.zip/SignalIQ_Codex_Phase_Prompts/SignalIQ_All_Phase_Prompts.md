# SignalIQ — Complete Codex Reconstruction Prompt Pack


---

# FILE: README.md

# SignalIQ — Codex Phase Prompt Pack

These prompts are intended to be pasted into Codex **one at a time**, in order. The user reviews each phase, pushes the resulting changes to Git, then starts the next prompt.

## Prompt order

1. `PROMPT_PHASE_0_AUDIT.md` — repo audit and factual baseline; no broad code changes.
2. `PROMPT_PHASE_1_UX_DESIGN.md` — lock the product UX and visual system using the actual reference screenshots.
3. `PROMPT_PHASE_2_FRONTEND.md` — rebuild the frontend and establish typed API boundaries.
4. `PROMPT_PHASE_3_AUTH_DATABASE_API.md` — add Supabase Auth, PostgreSQL persistence and ownership-scoped FastAPI endpoints.
5. `PROMPT_PHASE_4_AI_ENGINE.md` — harden Gemini analysis, provenance, issue aggregation and scoring.
6. `PROMPT_PHASE_5_WORKFLOWS_ADAPTION.md` — complete feedback workflows, reports, verified training examples and Adaption operations.
7. `PROMPT_PHASE_6_QA_DEPLOYMENT.md` — run comprehensive testing, security review and deployment verification.

## How to use

- Open the existing `SignalIQ` repository in Codex.
- Paste the complete contents of the next prompt file as one task. Do not paste multiple phase prompts together.
- Let Codex finish and read its phase report. Inspect the Git diff, then commit/push the phase yourself. Start the next phase only after reviewing the handoff.
- Use the commit message suggested at the end of each prompt as a starting point; adjust it to the real changes.
- Do not ask Codex to run destructive Git commands, wipe the project, publish credentials, or claim unverified integration/deployment success.

## Testing cadence

Phases 0–5 request focused checks relevant to current changes, not the entire release test cycle each time. Minimal checks are still important to avoid knowingly compounding missing imports, broken migrations, or broken integration contracts. Phase 6 is the comprehensive final test/release gate. Codex must always report exact checks run and not imply unrun tests passed.

## Non-negotiable product facts

- Product name: **SignalIQ**. `InsightFlow` is historical context only.
- Target: usable public-beta service, not the old nine-hour prototype.
- Frontend: retain React + TypeScript + Vite + Tailwind where practical; backend: FastAPI/Pydantic.
- Accepted target for identity/data: Supabase Auth + PostgreSQL, with verified auth and server-enforced workspace ownership.
- UI direction: warm editorial analytics; no dominant navy/blue AI-dashboard theme.
- Gemini handles live feedback analysis. Adaption Adaptive Data is separate dataset optimization—not the live classifier.
- Only explicitly reviewed/verified labels are eligible for the trusted Adaption training dataset by default.
- Never pretend a fallback, sample record, mock response, unverified provider call or untested deployment is real success.
- Do not commit/push automatically; the user handles the Git push after each phase.


---

# FILE: PROMPT_PHASE_0_AUDIT.md

# CODEX MASTER PROMPT — PHASE 0: REPOSITORY AUDIT & RECONSTRUCTION BASELINE

You are working inside the existing **SignalIQ** repository. This is Phase 0 of a controlled reconstruction—not permission to rebuild the whole application in one pass.

## Mission

Establish an accurate, repository-grounded view of the current codebase and verify that the new canonical documentation is present and internally consistent before any substantial application changes. We have already prepared and copied the reconstruction documentation; do not repeat the previous prototype build instructions or blindly regenerate the documentation bundle.

**Product identity:** SignalIQ — “Find the signal. Fix the problem.”  
**Product purpose:** turn customer feedback into traceable insights, explainable priorities, tracked actions, and reports.  
**Target:** a usable public-beta service, not a throwaway hackathon mockup.

## Required source-of-truth files

Read these before investigating or changing anything:

- `AGENTS.md`
- `README.md`
- `docs/DECISIONS.md`
- `docs/PRD.md`
- `docs/DEVELOPMENT_PHASES.md`
- `docs/UX_DESIGN_SPEC.md`
- `docs/DESIGN_SYSTEM.md`
- `docs/ARCHITECTURE.md`
- `docs/DATABASE.md`
- `docs/API_CONTRACTS.md`
- `docs/AI_AND_ADAPTION.md`
- `docs/SECURITY.md`
- `docs/TESTING.md`
- `docs/DEPLOYMENT.md`

If a file is missing, note it and create only the minimum canonical file needed; do not invent implementation facts.

## Task A — Establish the exact repository state

1. Inspect the current branch, current commit, working-tree changes, top-level folders, tracked assets, package manifests, backend requirements, environment examples, `.gitignore`, and existing deployment configuration.
2. Do not discard, reset, clean, stash, overwrite, or rebase the user's working tree. Do not perform destructive Git commands.
3. Inspect the actual frontend entry point, routing, shell, page components, state/persistence layer, API client, and data transformation functions.
4. Inspect the FastAPI entry point, routes, schemas, configuration, Gemini integration, Adaption integration, error handling, and job lifecycle.
5. Inspect the existing tests and available scripts. You may run quick read-only inspection commands. Do not conduct a full regression suite in this phase unless a very small check is needed to establish a baseline.
6. Open and visually inspect all images under `images/`, including `Dashboard reference.png`, `Feedback Explorer reference.png`, and `Insights and Actions reference.png`. Do not infer screenshot details from filenames alone. Describe their layout, hierarchy, color, density, typography, charts, and interactions as far as the screenshots support.
7. Inspect all additional relevant screenshots/images that are already in the repository and identify whether each is a desired reference, an old output, or unclear.
8. Search for outdated copied prompt bundles or documents, especially `docs_bundle/`, any ZIP containing old instructions, and duplicate `AGENTS.md` files. Do not delete anything yet. Identify conflicting sources and whether unique useful material needs preserving.

## Task B — Create a factual current-state map

Update `docs/CURRENT_STATE_AUDIT.md` with:

- Date/time of the audit and the exact checked-out commit SHA/branch.
- Repository tree summary and actual stack/dependency facts.
- Screenshot findings based on the actual image pixels.
- Each major feature's status using only these labels:
  - **Implemented and verified** — source exists and a relevant check was actually performed successfully.
  - **Implemented but unverified** — relevant source exists but runtime/credential/deployment behavior was not proven.
  - **Planned** — documented target behavior is not implemented yet.
- A map of relevant source files for the frontend shell/routes, feedback state, import/export, charts/metrics, Gemini, Adaption, persistence, authentication, database, tests, and deployment.
- Current behavior and gaps, with evidence in paths/function names where practical.
- Existing useful code to preserve and code likely requiring replacement.
- Known blockers, environmental limitations, credentials unavailable, and checks not performed.

Specifically investigate and report the current status of browser `localStorage`, account/auth flows, server-side database persistence, workspace isolation, Gemini live analysis, rule-based fallback, priority-score implementation, Adaption dataset creation, human verification of labels, confirmation before potentially billable runs, Adaption job persistence, report/export flows, and deployment. Existing source code is not proof a live provider or deployment works.

## Task C — Reconcile documentation, but do not redesign it here

- Confirm that the canonical documents agree about the product name, scope, stack, phases, visual design, authentication/persistence, and Adaption's role.
- The active name is **SignalIQ**. `InsightFlow` may be mentioned only as historical context.
- Target visual direction is **warm editorial analytics**: warm ivory/stone, charcoal, muted forest/sage green, restrained terracotta/amber, thoughtful typography, and no dominant navy-and-blue AI-template look.
- Target architecture retains React + TypeScript + Vite + Tailwind on the frontend and FastAPI/Pydantic on the backend unless a real blocker is discovered. Supabase Auth + PostgreSQL are the accepted target direction; verify exact integration details in the implementation phase using official current documentation.
- Gemini is the current live-analysis provider. Adaption is a separate training-data optimization workflow and must not be presented as the current live classifier.
- Fix a documentation contradiction only if the repository gives clear evidence. Update all dependent docs consistently and record material decisions in `docs/DECISIONS.md`.
- Do not add features to the product scope and do not rewrite the app during this task.

## Explicitly out of scope

- Do not implement authentication, database migrations, new API endpoints, or redesigned application screens.
- Do not create a new repository or replace the stack.
- Do not run broad UI changes.
- Do not delete old prompt bundles or other potentially useful assets until their unique content has been reviewed and a cleanup step is explicitly assigned.
- Do not claim tests, real Gemini/Adaption calls, database access, or deployment are verified without evidence.

## Completion requirements

1. Update `docs/CURRENT_STATE_AUDIT.md` with factual local-repository findings.
2. If canonical docs were missing or demonstrably contradictory, make only the narrow necessary corrections and list every changed document.
3. Provide a concise phase report: inspected paths, exact commands/checks performed and outcomes, implemented/verified vs unverified vs planned findings, reference-image observations, blockers, and recommended next phase.
4. Do not commit or push; the user will review and push the phase changes.

Suggested commit message: `docs: audit SignalIQ reconstruction baseline`


---

# FILE: PROMPT_PHASE_1_UX_DESIGN.md

# CODEX MASTER PROMPT — PHASE 1: UX ARCHITECTURE & DESIGN LOCK

You are working inside the existing **SignalIQ** repository. This is Phase 1 of a phased reconstruction. Read this prompt fully and obey the canonical project docs. Do not implement the entire app in this phase.

## Product context

SignalIQ — “Find the signal. Fix the problem.” — turns customer feedback into traceable insights, explainable priorities, tracked actions, and reports. The target is a usable public-beta service, not a generic AI dashboard or a rushed demo.

## Read first

Read `AGENTS.md`, `README.md`, `docs/CURRENT_STATE_AUDIT.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/DEVELOPMENT_PHASES.md`, `docs/UX_DESIGN_SPEC.md`, and `docs/DESIGN_SYSTEM.md`. Also inspect the existing frontend structure and all original image assets in `images/` directly.

## Approved creative direction

Use **warm editorial analytics**: warm ivory and stone surfaces, charcoal typography, forest/sage green for the core positive/action accent, restrained terracotta or amber for selected attention states, soft neutral dividers, intentional whitespace, and distinctive information hierarchy. Avoid a dominant navy/blue sidebar, the familiar all-white/blue AI-generated dashboard aesthetic, excessive rounded cards, decorative gradients, oversized headings, unnecessary glow/shadows, and generic dashboard repetition.

The user has already approved this direction. Do not pause just to ask which color family they prefer. Make sensible, consistent design choices under the documented constraints. Do not alter the product brand from SignalIQ.

## Task 1 — Inspect and interpret the reference screenshots

- Open the actual images in `images/`; assess each at readable size.
- Identify useful information-architecture and interaction patterns, not merely their color palette.
- Separate “reference inspiration” from “elements to change.”
- Record the observations in `docs/UX_DESIGN_SPEC.md`; do not claim pixel-specific observations you did not make.

## Task 2 — Lock the complete product UX

Specify the screen inventory, hierarchy, user goals, navigation model, primary/secondary actions, empty/loading/success/partial-success/error states, keyboard/focus behavior, responsive behavior, and key transitions for:

1. Public product/entry route and sign-up/sign-in/recovery flows.
2. First-use onboarding and a clearly labeled synthetic sample dataset option.
3. Overview dashboard: KPIs, sentiment and trend views, recurring issues, priority queue, evidence, and contextual next action.
4. Feedback Explorer: source data, search, sort, filters, row details, add/edit/delete, CSV preview/mapping/validation/import progress and rejected-row reporting.
5. Insights: theme/issue summaries with evidence links, date coverage, confidence/provenance, and filter-aware analysis.
6. Priorities & Actions: score explanation, volume, negative share, severity/trend availability, supporting comments, recommendation, status lifecycle (`Open`, `In progress`, `Resolved`), and persisted changes.
7. Reports: report scope, date range, metric definitions, evidence coverage, and CSV/HTML or other documented downloadable formats.
8. Data Quality & Adaptation: review/correct labels, mark an example verified, choose eligible examples, preview/export data, request an Adaption estimate, explicit confirmation before running, actual provider status, errors, and available output download.
9. Settings: account/session state and workspace/account options in scope for v1. Do not add billing or team management.

For each screen document: purpose, target user question, layout regions, hierarchy, important content, control behaviors, data dependency, mobile adaptation, and failure/empty state. Make sure no page is included in navigation unless its planned or implemented behavior is specified.

## Task 3 — Make the design system actionable

Update `docs/DESIGN_SYSTEM.md` with usable semantic tokens and rules, including:
- Canvas, surface, elevated surface, text, muted text, border, primary/action, positive, warning, and destructive tokens.
- Typography roles, type scale, line lengths, density, spacing rhythm, sizing and responsive breakpoints.
- Buttons, inputs, selects, tables, filter chips, navigation, KPI blocks, chart framing, issue rows, dialogs, banners/toasts, badges, skeletons, and empty/error states.
- Focus-visible and keyboard-accessibility requirements.
- Rules for color contrast and never using color alone to encode sentiment/severity/status.
- Desktop, tablet, and mobile behavior, including readable data tables and usable filters.

Use restrained color, but don't force every element into a card. Prefer varied but consistent layouts and allow important data to have room.

## Task 4 — Define interaction and component contracts

- Provide a shared component inventory with responsibilities and variants.
- Decide which interactions belong to links/routes, dialogs, inline editors, filters, or server actions.
- Every visible control must do something real, be explicitly disabled with an explanation, or be removed.
- Charts and KPIs must eventually use current data and the active filter set. Do not prescribe hardcoded live-looking numbers.
- Clarify loading and asynchronous feedback for long AI/Adaption tasks.
- Specify an evidence pattern so each insight or recommended action can be traced to actual comments.

## Task 5 — Deliver a concrete implementation blueprint

- Update `docs/UX_DESIGN_SPEC.md` and `docs/DESIGN_SYSTEM.md`.
- If needed, append a numbered decision to `docs/DECISIONS.md` for a material new product/design decision; do not overwrite older history.
- Produce a prioritized screen/component implementation map for Phase 2.
- If the repository already has an accepted UI preview mechanism, you may create a minimal design preview, but do not perform broad page reconstruction here or introduce a new design framework solely for the preview.

## Constraints

- Do not change backend architecture or schema in this phase.
- Do not introduce dependencies without a clear need.
- Do not replace the supplied screenshots with generated assets or generic UI inspiration.
- Do not change product scope, branding, or documented non-goals.
- Do not stop for routine clarification; use the documented decisions and note genuine unresolved blockers.

## Focused checks and handoff

This is primarily a design/specification phase, so do not run a full application regression suite. Check markdown consistency/links if tooling exists, inspect the final diff, and verify all documented screens map to PRD requirements.

Report the files changed, design decisions locked, screenshot observations, any contradictions found, and how the Phase 2 implementation will follow the approved design. Do not commit/push; the user will do so.

Suggested commit message: `docs: lock SignalIQ UX and visual system`


---

# FILE: PROMPT_PHASE_2_FRONTEND.md

# CODEX MASTER PROMPT — PHASE 2: FRONTEND & UI/UX RECONSTRUCTION

You are rebuilding the frontend of **SignalIQ** within the existing repository. This phase implements the approved product experience—not another throwaway prototype. Work only on the frontend and its documented API/data-access boundary; the persistent backend is the next phase.

## Product and source of truth

Product: SignalIQ — “Find the signal. Fix the problem.”  
Goal: connect customer feedback to traceable insights, explainable priorities, actions, and reports.  
Visual direction: warm editorial analytics; warm ivory/stone, charcoal, muted natural greens, restrained terracotta/amber. Do not reintroduce the previous dominant navy/blue aesthetic.

Read `AGENTS.md`, `docs/CURRENT_STATE_AUDIT.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/UX_DESIGN_SPEC.md`, `docs/DESIGN_SYSTEM.md`, `docs/ARCHITECTURE.md`, and `docs/API_CONTRACTS.md`. Inspect existing source and tests before replacing anything. Reuse useful logic and dependencies where sensible; do not blindly delete all components.

## Scope of this phase

Reconstruct the React + TypeScript + Vite + Tailwind frontend, route hierarchy, design tokens, shared components, screen layouts, interactions, data-access abstractions, and user-facing states. Create public/auth route shells and authenticated workspace screens. Backend calls that do not exist yet must be represented through a typed API contract and a clearly isolated development fixture/adapter—not scattered hardcoded mock data.

Do not build the complete authentication/database backend here. Do not claim sign-up, real persistence, Gemini, or Adaption works unless those routes are already present and verified. Prepare the frontend to connect to Phase 3+ APIs without a rewrite.

## Task 1 — Establish a maintainable frontend structure

- Preserve the current project tooling and dependencies unless a concrete limitation is documented.
- Define clear boundaries among routes/pages, reusable UI components, domain types, API client, data mapping, derived metrics, and demo fixtures.
- Use strict TypeScript; avoid `any`, repeated business logic in UI components, and giant single-file page components.
- Centralize design tokens and shared layout rules. Avoid duplicate hardcoded color/spacing styles across pages.
- Keep API types aligned to `docs/API_CONTRACTS.md`; where contracts need a specific adjustment, update both the canonical doc and implementation consistently.
- Build environment-aware API URL configuration without embedding secrets in frontend environment values.

## Task 2 — Implement the application shell and routes

Create a cohesive responsive shell with:
- SignalIQ branding and consistent page titles/descriptions.
- Appropriate authenticated navigation for Overview, Feedback, Insights, Priorities & Actions, Reports, Data Quality & Adaptation, and Settings.
- Clear sign-in/sign-up/recovery entry states.
- A mobile navigation pattern that works with keyboard and touch.
- Context-appropriate page actions; no placeholder buttons.
- Account/workspace/loading/session-expired/error presentation based on the actual available data/session interface.

Route guards may use an explicit auth abstraction placeholder until Phase 3 completes, but do not pretend it is secure authentication. Make the boundary obvious in code and UI states so Phase 3 can replace it cleanly.

## Task 3 — Build all primary screens according to `UX_DESIGN_SPEC.md`

### Overview
- Display KPIs, sentiment mix, trend visualization, top issues, and a priority/action queue.
- Derive all data from the current fixture or API response; never hardcode KPI values as product logic.
- Show date range and filter scope consistently. Every chart/list/KPI that should respond to filters must share the same filtering contract.
- Provide honest first-run, no-data, filtered-empty, loading, and error states.

### Feedback Explorer
- Implement search, sorting, filters, page size/pagination or a scalable list pattern, row detail, add/edit/delete interactions, and CSV import UI.
- CSV flow: choose file, detect candidate columns, preview records, let user correct ambiguous mappings, validate rows, show accepted/rejected counts with reasons, and confirm import.
- Do not silently discard invalid rows or claim persistence where it is not implemented.
- Properly handle quotes, commas, Unicode, blank rows, bad dates/ratings, duplicate imports, long text, and formula-like spreadsheet values in exports.

### Insights
- Show coherent issue/theme summaries, time coverage, sentiment, severity signal, confidence/provenance, supporting feedback, and evidence navigation.
- Clearly differentiate real AI, demo/rules-based, unclassified, and not-yet-reviewed records.

### Priorities & Actions
- Show issue ranking with a plain-language score breakdown and the current weights from `docs/DECISIONS.md`.
- Show source comments supporting each issue and an action recommendation tied to evidence.
- Implement status controls for `Open`, `In progress`, and `Resolved` through the data-access abstraction.
- Don't label a local-only state as saved to the account/server. Use a visibly local development adapter until persistent APIs arrive.

### Reports
- Provide scope/date controls, preview, accurate metric labels, and a download action through a typed export utility.
- Report data must be derived from the selected dataset and filters; do not invent chart data or counts.

### Data Quality & Adaptation
- Provide label review/correction and verified-example selection UI according to `AI_AND_ADAPTION.md`.
- Display whether the provider is configured only when the backend health/config API supplies that information.
- Prepare an explicit estimate → confirmation → run → status → download UI. Do not automatically start a run. Do not claim an external run succeeded.

### Settings and account surfaces
- Show only settings supported by the product scope. Do not add billing or team invitation screens.

## Task 4 — Visual execution bar

- Inspect original repository references directly and use the findings documented during Phase 1.
- Apply the approved tokens consistently across all views.
- Use distinct page compositions and appropriate density, not identical grids of rounded white cards everywhere.
- Charts require meaningful axes/labels, responsive sizing, and empty states.
- Use accessible semantic HTML, visible focus, form labels, keyboard-safe dialogs, and sufficient contrast.
- Support approximately 390px mobile and 1366px desktop layouts. Prevent accidental page-wide horizontal overflow.
- Use realistic synthetic data only in clearly marked fixtures. Keep fixtures separate from production-facing API behavior.
- Never add people/avatars or decorative AI imagery where not useful to this analytical product.

## Task 5 — Integration readiness

- Implement a typed API client with clear response/error parsing and consistent loading/error behavior.
- Separate frontend-only derived calculations from server-owned persisted state.
- Add explicit adapter boundaries for auth/session, feedback CRUD/import, analysis runs, issue state, reports, and Adaption jobs.
- Use the planned API contracts and don't assume endpoints exist. If a route is unimplemented, represent it as a truthful unavailable state in development, not a fake success.
- Make the later switch to real APIs a targeted adapter implementation, not a rewrite of every page.

## Out of scope

- No database/auth backend implementation in this phase.
- No real review platform ingestion or billing.
- No invented live provider result.
- No large unrelated dependency upgrades or wholesale repository replacement.

## Completion

Use the available scripts to run a focused frontend typecheck/build or targeted checks only as practical; the comprehensive regression suite is reserved for Phase 6. Do not claim a check passed unless it ran. Fix obvious implementation-caused blockers before handing off, especially missing routes/imports and TypeScript errors.

Inspect the diff and report: screens implemented, controls wired, API placeholders/boundaries, responsive observations, known limitations, checks actually run, and suggested next phase. Do not commit or push; the user will do so.

Suggested commit message: `feat: reconstruct SignalIQ frontend experience`


---

# FILE: PROMPT_PHASE_3_AUTH_DATABASE_API.md

# CODEX MASTER PROMPT — PHASE 3: AUTHENTICATION, DATABASE & PERSISTENT API

Implement SignalIQ's persistent, multi-user service foundation in the existing repository. This is a backend/platform phase. Keep the approved frontend intact except for the minimum integration changes needed to connect real authentication and API data access.

## Product context and source of truth

SignalIQ is a public-beta customer feedback intelligence service. It must not use browser `localStorage` as the source of truth for signed-in user feedback or issue states. One account gets one private default workspace in v1; team collaboration and billing are out of scope.

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md`, and the current audit. Inspect the existing FastAPI code, frontend auth/API adapter, environment handling, dependency files, tests, and deployment setup before implementation.

## Accepted architecture

- Keep FastAPI/Pydantic as the application API.
- Use Supabase Auth for identity and managed PostgreSQL for durable application data, as specified in `docs/DECISIONS.md`.
- Verify all SDK/auth/database integration details against current official Supabase documentation. Do not invent SDK functions or copy deprecated examples.
- Browser auth uses only the appropriate public/publishable configuration required by the current SDK. Privileged database credentials stay server-side.
- The frontend sends the authenticated access token to FastAPI. FastAPI must validate token signature/issuer/audience/expiry using the documented supported approach before trusting identity claims.
- Every database operation must be scoped to the authenticated user's private workspace. A browser-provided `user_id` or `workspace_id` is never proof of ownership.
- If the backend uses a privileged/service database credential that bypasses RLS, implement explicit server-side ownership checks on every operation and document this. RLS can be defense-in-depth, but do not falsely claim that RLS protects queries executed with a bypass role.
- Use repeatable version-controlled schema migrations. If a migration tool is not present, choose a minimal maintained tool compatible with this repository, document the choice, and use it consistently.

## Task 1 — Database schema and migrations

Implement the normalized schema in `docs/DATABASE.md` using migrations. At minimum support:

- User-owned private workspaces and the authenticated owner association.
- Feedback records, source/date/rating, analysis fields, analysis provenance/status, and timestamps.
- Issue state/tracking that is stable across refresh and server restarts.
- Analysis runs/batches and per-record outcome/provenance as needed for partial success/retries.
- Human-reviewed training examples or explicit verified-label state.
- Adaption application job metadata and its workspace/owner association, including dataset/run identifiers, current phase/status, row counts, estimates where returned, errors safe to persist, timestamps, and output readiness.
- Any report metadata only if the implemented requirements justify storing it; otherwise generate reports from authorized query results.

Add constraints, foreign keys, useful indexes, created/updated timestamps, and transaction behavior. Store dates consistently and document the timezone policy. Use durable metadata; do not store large sensitive source text in operational logs.

## Task 2 — Authentication and onboarding

- Implement sign-up, sign-in, sign-out, token/session refresh, and account recovery according to the current official Supabase-supported frontend flow.
- Add a safe first-user bootstrap: create or find that user's private default workspace idempotently. Avoid race-created duplicate default workspaces.
- Handle signed-out, expired-session, network/provider-error, and recovery states accessibly.
- Verify bearer tokens on the server for every private endpoint; do not trust a client-supplied email/user ID.
- Avoid logging access tokens or secrets.

## Task 3 — Persistent API

Implement or align the API endpoints in `docs/API_CONTRACTS.md` for:

- Health and non-sensitive application/provider readiness.
- Authorized feedback list/filter/pagination/detail/create/update/delete and CSV import where specified.
- Authorized issue state read/update.
- Analysis-run metadata and results needed by Phase 4.
- Verified training-example selection and Adaption job metadata needed by Phase 5.

For every private route:
- Establish the authenticated principal first.
- Resolve the private workspace server-side.
- Scope every select/update/delete to that workspace or owner.
- Verify a resource belongs to the workspace before returning or changing it.
- Return consistent error shapes and appropriate HTTP status codes.
- Bound pagination, row count, text size, import size, and other user-controlled costs.
- Do not expose database internals, secrets, token claims unrelated to the UI, or stack traces.

Do not create generic overpowered CRUD endpoints that bypass domain checks. Prevent cross-account access to records by guessing IDs.

## Task 4 — Frontend integration

Replace Phase 2 placeholder/local adapter behavior for auth and persistent feedback/issue state with a thin real API integration. Preserve the approved design and reusable component boundaries. Remove browser persistence as the authority for real account data. `localStorage` may be used only for harmless preferences or non-sensitive transient UX where documented—not as silent fallback storage for server failures.

If an existing local sample workspace exists, do not automatically upload it to a user account. Offer an explicit import/migration choice only if implemented and documented. Keep clearly labeled sample/demo data isolated from real records.

## Task 5 — Security and migration readiness

- Use environment variables for server secrets and update `.env.example` with placeholders only.
- Confirm `.env`, secrets, database exports, downloaded customer data, virtual environments, and build output follow `.gitignore` policy.
- Validate input types/limits and consistently normalize errors.
- Make migrations repeatable on a fresh database and safe for an upgrade path. Never run destructive data resets.
- Write/adjust authorization tests for allow and deny paths, including two separate accounts and attempts to access each other's resource IDs.
- Document database/auth setup and required secrets without adding real keys.

## Constraints and workflow

- Do not start Gemini redesign or implement the full Adaption workflow here; this phase provides the persistence/security foundation they will use.
- Do not add teams, billing, third-party feedback connectors, or complex organization roles.
- Check current official docs before settling on exact token verification, JWT/JWKS, client, and database-driver details.
- Do not ask routine questions. Use accepted decisions; if credentials are unavailable, implement the correct configuration/error path and clearly mark live verification as blocked.
- Do not claim public production readiness merely because auth code exists.

## Focused checks and handoff

Run only focused migration/auth/API checks practical in this phase; reserve broad end-to-end/full-suite validation for Phase 6. Never describe unrun tests as passed. Review all private routes for ownership enforcement before handoff.

Report schema/migrations, auth implementation, private endpoints, how identity and ownership are checked, checks actually run, missing service credentials, and unverified manual tasks. Do not commit/push; the user will do so.

Suggested commit message: `feat: add authenticated persistent SignalIQ service`


---

# FILE: PROMPT_PHASE_4_AI_ENGINE.md

# CODEX MASTER PROMPT — PHASE 4: GEMINI ANALYSIS & EXPLAINABLE INSIGHTS

Implement SignalIQ's real, persistent AI-analysis workflow on top of the authenticated API and database created in Phase 3. Focus on safe analysis, accurate provenance, explainable issue aggregation, and persistence. Do not redesign the whole frontend or implement Adaption's full operations in this phase.

## Read first

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/API_CONTRACTS.md`, `docs/AI_AND_ADAPTION.md`, `docs/DATABASE.md`, `docs/SECURITY.md`, `docs/TESTING.md`, and `docs/UX_DESIGN_SPEC.md`. Inspect the current Gemini client, FastAPI analysis route, Pydantic schemas, frontend analysis adapter, data model, persistent tables, and tests. Preserve useful provider code after verifying it.

## Non-negotiable product rule

Gemini analyzes current customer feedback. Deterministic application code aggregates data, groups issues, calculates metrics and priority scores, and ensures that evidence links are accurate. Adaption is a separate training-data optimization workflow and is not the live classifier.

Never fabricate a label, reason, score, trend, provider result, or successful call when a request fails. Never label rule-based output as live Gemini analysis.

## Task 1 — Define the analysis contract

Implement/align a validated request and response contract that supports:

- Stable feedback record IDs and bounded comment text.
- Sentiment: positive, neutral, negative, or an explicit unclassified/failure state where the schema requires it.
- Consistent category and normalized issue key.
- Severity: low, medium, high, with unknown/not-yet-reviewed handled outside a forced AI assertion if necessary.
- Concise summary/explanation grounded only in the feedback.
- Optional model confidence only when the model/protocol meaningfully supplies it; do not present uncalibrated confidence as a probability of truth.
- Analysis mode/provider/model/version, timestamps, run ID, and per-record status/provenance as appropriate.
- Optional suggested action that must be supported by the observed feedback and should remain reviewable by the user.

Validate every model response. Reject malformed records, unexpected IDs, duplicate IDs, missing required fields, unsupported enum values, excessive lengths, and ungrounded data fields as far as practical. Do not trust LLM-produced totals or computed metrics.

## Task 2 — Harden live Gemini calls

- Keep API keys server-side.
- Use the current supported Google Gen AI SDK/provider call structure in this repository; verify uncertain behavior against current official documentation.
- Use bounded batches, explicit timeouts, configured model selection, and clear handling for missing key, authentication failure, rate limit, timeout, provider outage, invalid response, and partial per-record result failure.
- Prevent a failed or partially malformed run from wiping valid prior analysis. Persist successful valid rows transactionally, preserve failures and retryability, and disclose partial completion.
- Avoid sending direct identifiers/sensitive content to external providers when possible. Apply documented redaction and remind users that basic redaction is not anonymization.
- Do not log full raw feedback or secrets by default.
- Use idempotent run/job handling or a documented retry key so refresh/retry does not create uncontrolled duplicate analysis.
- Make cancellation/retry behavior explicit if implemented; do not expose pretend controls.

## Task 3 — Keep demo analysis honest

- Preserve a deterministic, testable demo/rules fallback only for deliberate demo mode or a clearly handled missing-provider scenario consistent with product docs.
- Clearly label `live-ai`, `demo-rules`, `unclassified`, and `failed` states in UI and stored data.
- Do not silently convert provider failure into an apparently successful live result.
- Do not overwrite a valid live classification with a demo result without deliberate user action.
- Provide useful error messages and recovery options while retaining source feedback.

## Task 4 — Build a deterministic insight and priority engine

In application code—not inside LLM counting—calculate aggregates from authorized persisted records and active filter scope. Follow `docs/DECISIONS.md`:

- Initial weight: frequency 40%, negative sentiment share 30%, trend 20%, severity 10%.
- Normalize available components to 0–100 and document definitions and bounds.
- Only calculate trend with adequate date coverage and a clearly stated comparison method.
- When trend is unavailable, redistribute its weight proportionally across available components and explicitly mark trend as unavailable.
- Handle zero records, missing dates, mixed date coverage, timezone boundaries, duplicate feedback, and small denominators safely.
- Keep grouping keys normalized and stable. Avoid accidental merging of distinct issues based only on similar phrases unless supported by a deterministic documented method.
- Ensure the frontend/report can show score components and relevant supporting feedback IDs/excerpts.
- Recommendations must be tied to actual issue evidence. Use reviewed structured AI output with strict validation or deterministic, documented category-based rules. Do not write generic advice and falsely claim it follows from unseen evidence.

## Task 5 — Human review and label provenance

Implement the data/service support needed for users to review and correct sentiment/category/severity/summary, if not already built. Track at minimum whether a value came from live AI, demo rules, or human correction/review, with timestamps and a review state. Keep source analysis history/provenance understandable; a correction should not make the original provider result indistinguishable from the reviewed version.

Only explicitly reviewed/verified examples may qualify for the trusted Adaption dataset in Phase 5. Do not mark an AI or rules label as verified automatically.

## Task 6 — Connect frontend states to the real analysis APIs

- Wire the UI to persistent analysis endpoints.
- Show progress, successful rows, failed rows, provider mode, and actionable error/retry states.
- Recalculate KPIs, charts, issue groups, and priority order from saved results and the same active filter scope.
- Handle session expiry and permission errors without leaking one user's data.
- Preserve a usable experience when Gemini is not configured, but disclose the mode and limitations.

## Constraints

- Do not claim analysis is clinically/financially validated or that the priority weights are an industry standard.
- Do not integrate an adapted model into live inference.
- Do not implement Adaption run lifecycle in this phase except the reviewed-label/verified-example foundation.
- Do not add unrelated external review sources, billing, or team features.

## Focused checks and handoff

Do targeted checks around Pydantic validation, provider failure handling, persistence and priority calculations as practical. Full suite and end-to-end validation are reserved for Phase 6. Note tests not run and never claim live Gemini verified if credentials/provider access are unavailable.

Report data contract, model/provenance behavior, issue-scoring rules, changes to frontend/API/database, focused checks, provider limitations, and suggested next step. Do not commit/push; the user will do so.

Suggested commit message: `feat: add explainable Gemini feedback analysis`


---

# FILE: PROMPT_PHASE_5_WORKFLOWS_ADAPTION.md

# CODEX MASTER PROMPT — PHASE 5: COMPLETE FEEDBACK WORKFLOWS, REPORTS & ADAPTION

Complete SignalIQ's end-to-end customer-feedback journey on the real authenticated APIs and persisted data. This phase integrates the frontend, database, analysis engine, reporting, and Adaption workflow. Do not convert any workflow to a fake success or in-memory-only feature.

## Read first

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/UX_DESIGN_SPEC.md`, `docs/API_CONTRACTS.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/AI_AND_ADAPTION.md`, `docs/SECURITY.md`, and `docs/TESTING.md`. Inspect actual Phase 2–4 code, migration state, current frontend API adapters, Gemini outputs/provenance, CSV utilities, report utilities, and Adaption SDK code. Reuse rather than duplicate existing good functionality.

## Core acceptance journey

A signed-in user must be able to:

1. Add a feedback comment or import a CSV.
2. Preview/map/validate the input and see accepted/rejected row counts.
3. Persist the records into their private workspace.
4. Run live Gemini analysis where configured, or consciously select a clearly labeled available demo flow.
5. See analysis saved to the correct records with provenance/status.
6. Filter feedback and see matching counts/charts/issue groups.
7. Open an issue, inspect actual supporting feedback, and understand its priority breakdown.
8. Change issue status, refresh, and confirm the state persisted.
9. Export a report and compare its numbers/evidence with the selected data.
10. Review/correct labels and select only explicitly verified examples for Adaption.
11. Preview and export the training dataset, estimate a real Adaption job, explicitly confirm a run, monitor actual provider status, and download actual output only when ready.

## Task 1 — Finish feedback CRUD, import and consistent filters

- Wire add/edit/delete, search, sorting, filtering, pagination and record detail to authenticated persistent APIs.
- Make CSV import resilient and transparent. Support common aliases for comment text, date, rating, and source. Show sample preview and candidate mappings; request correction if ambiguous. Handle Unicode/encoding, BOM where applicable, commas, quotes, blank rows, malformed values, oversized files, duplicates/retries and row limits.
- Report imported/accepted/rejected row counts and useful row-level failure reasons. Never silently discard rows.
- Avoid partial duplicated writes after retries; use idempotency or stable duplicate-detection policy documented in the product.
- Ensure imported records belong to the authenticated user's workspace. Never permit an upload to select another user's workspace by a client ID.
- Make all main-page metrics, charts, issues, and exports agree with the same selected workspace/filter/date scope.

## Task 2 — Finish priorities and action tracking

- Show stable issue grouping, actual support count and example excerpts/links, sentiment mix, severity information, date coverage, trend only when enough data exists, and an explainable priority score.
- Follow the weighting and missing-trend behavior in `docs/DECISIONS.md`; do not invent a trend if the dataset cannot support it.
- Tie suggested next actions to observed feedback and keep them concise and reviewable.
- Persist `Open`, `In progress`, and `Resolved` states and reflect changes across dashboard, issue pages, and reports.
- Maintain a useful status history/timestamp if included in the agreed data model; do not delete evidence when an issue resolves.

## Task 3 — Deliver accurate reporting and exports

- Implement the documented downloadable report format(s), CSV export, and print/download flow where specified.
- Include report scope, selected date range, dataset size, data coverage, KPI definitions, top issues, priority component breakdown, recommendations, and traceable evidence where appropriate.
- Derive every number from the authorized selected data. Include limitations for missing dates, incomplete analysis, synthetic sample data, and unavailable trend.
- Escape user-provided feedback safely in HTML. Prevent spreadsheet formula injection in CSV exports. Do not execute or trust imported cell content.
- Avoid rendering arbitrary raw HTML from comments or model output.
- Ensure only the authorized owner can generate/download a report from their private data.

## Task 4 — Build a reviewable Adaption dataset workflow

Adaption is **not the live classifier**. It is a separate workflow to prepare/optimize a task-specific dataset for downstream model development. Do not claim that the resulting data automatically changes Gemini's predictions.

Implement these steps with accurate states:

### A. Prepare and curate examples
- Select only explicitly reviewed/verified records by default.
- Display why each example is eligible/ineligible and preserve source-record IDs/provenance without needlessly exposing personal data in exported files.
- Let a user inspect/correct targets and select a bounded set of examples.
- Show input/output schema and column mapping preview; reject empty or structurally invalid examples.
- Allow downloading the source CSV before provider upload.
- Clearly explain what data will be sent to Adaption and require deliberate user action to upload/run.

### B. Estimate
- Use the current supported official Adaption Python SDK. Verify package/API method names and response shapes against current official Adaption documentation rather than assuming old shapes remain valid.
- Upload the prepared supported dataset, wait for provider ingestion/status, and request `estimate=True` using the correct column mappings for actual CSV headers.
- Display only estimates/IDs/status returned by the provider. Never invent a cost, duration, dataset ID, or success response.
- Treat estimates and runs as separate API operations.

### C. Explicit confirmation and run
- After showing the estimate, require a fresh, explicit confirmation before starting any operation that may consume credits.
- The server must enforce confirmation; hiding/greying the frontend button is not the only control.
- Never start or resume a billable run merely by opening a page, reloading, polling, or retrying a GET request.
- Prevent accidental duplicate submission with an idempotent or clearly recoverable run state.

### D. Persist job history and ownership
- Store the application job metadata in PostgreSQL, including owner/workspace, provider dataset/run IDs, phase/status, estimates returned, timestamps, progress, safe error details, and output availability.
- Replace in-memory-only job storage as the authority. A server restart must not erase SignalIQ's knowledge of created jobs.
- Re-check authorization on every estimate/run/status/download endpoint. Never expose another user's provider dataset or job by guessing a job ID.
- Where possible, recover status using persisted provider identifiers after restart. If the provider state can no longer be recovered, show an honest recovery/error state.
- Do not store provider secrets in job rows.

### E. Status and output
- Poll through a bounded, backoff-aware strategy or documented asynchronous mechanism; stop polling on terminal states and handle network failure.
- Map provider-reported success/failure/status values correctly according to current SDK docs. Unknown states are not success.
- Enable download only when provider output is actually available. Download the actual output, report failures, and clean temporary files.
- Clearly state that output is a dataset for downstream model development, not proof of a trained or evaluated model.
- When credentials are missing, implement a clear unavailable/configuration state without simulating a successful job.

## Task 5 — Reliability and interaction details

- Check loading, empty, partial-success, retry, validation failure, session expiry, permission denial, timeout, missing-key, provider failure, and download-not-ready states.
- Keep user-facing language clear and informative. No dead buttons or decorative “working” progress bars.
- Do not log raw comments, auth tokens, dataset content, or secrets unnecessarily.
- Apply sensible file, row, text, response-size, and processing-time limits.

## Constraints

- Do not add automatic external actions, billing, live ingestion integrations, team collaboration, AutoScientist or automatic model promotion.
- Do not remove a working feature just because integration takes effort; reuse existing importer/report/provider code where safe.
- Do not fake successful requests when credentials are unavailable.

## Focused checks and handoff

Test the changed boundaries where practical: import validation, score/report consistency, owner-scoped resources, Adaption confirmation enforcement, job persistence, provider-state mapping, and download readiness. Do not run the entire final release suite yet; Phase 6 is the comprehensive testing/release gate. Report every skipped check accurately.

Provide a final phase summary mapped to the ten-step core journey above and explicitly state which steps are implemented and verified, implemented but unverified, or still planned. Do not commit/push; the user will do so.

Suggested commit message: `feat: complete SignalIQ feedback and adaptation workflows`


---

# FILE: PROMPT_PHASE_6_QA_DEPLOYMENT.md

# CODEX MASTER PROMPT — PHASE 6: FULL QA, SECURITY HARDENING & PUBLIC-BETA DEPLOYMENT

This is the final verification and release phase for SignalIQ. Unlike earlier phases, now perform the comprehensive test, security, integration, and deployment checks. Do not describe the product as released or fully functional until the applicable checks have actually passed.

## Read first

Read `AGENTS.md`, `README.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/DEVELOPMENT_PHASES.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md`, `docs/AI_AND_ADAPTION.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md`, and `docs/CURRENT_STATE_AUDIT.md`. Inspect the complete codebase, test scripts, migrations, environment examples, CI/deployment files and actual Git diff/branch. Use current official provider documentation for any deployment/auth/API detail that may have changed.

## Task 1 — Run the full project quality suite

Inspect package scripts and backend setup; run the real configured commands, including where available:

```bash
npm --prefix frontend run typecheck
npm --prefix frontend test
npm --prefix frontend run build
```

Run backend tests from the correct environment, for example on Windows:

```powershell
.\.venv\Scripts\python.exe -m pytest
```

or the actual configured equivalent. Also run the migration checks, formatting/lint commands if present, and any configured end-to-end/browser checks. Do not assume commands, test files, or dependencies exist; inspect first.

- Record exact commands, exit codes, and meaningful failure summaries.
- Fix bugs caused by implementation where feasible, and rerun failed checks.
- Don't suppress/skip tests just to get a green result. Report environment blockers plainly.
- Ensure automated tests do not require live provider credentials; live tests should be explicit/manual or separately marked.

## Task 2 — Verify end-to-end product scenarios

Use the available integration/browser tooling or a deployment-equivalent environment to exercise:

1. Sign up a new account and verify its private workspace initializes once.
2. Sign in/out, refresh the session, and handle expiration/invalid tokens.
3. Import a CSV with valid and invalid rows; verify preview, mapping, counts, and persistence.
4. Add/edit/delete a feedback record; verify the owner and changes are correct after refresh.
5. Run analysis with configured Gemini or choose an explicitly labeled demo path; verify results/provenance are stored correctly.
6. Exercise missing-key, provider timeout/rate-limit, malformed response, partial result, and retry paths without fabricated classifications or data loss.
7. Filter feedback and verify KPIs, chart values, issue groups, priorities, and reports agree on the same scope.
8. Open a prioritized issue and inspect evidence; update status; refresh and verify persistence on dashboard, issue list, and report.
9. Generate/download reports and CSV. Inspect formula-injection protection and HTML escaping.
10. Create a second account and attempt to access account A's feedback, issues, analyses, reports, and Adaption jobs through both UI and direct API/resource IDs. Every unauthorized attempt must fail without leaking data.
11. Restart the backend and verify persistent records, migrations, issue status, and Adaption job metadata are preserved.
12. Verify the responsive interface on approximately 390px mobile and 1366px desktop; ensure navigation, import dialogs, filters, charts, tables, and important actions remain usable.
13. If genuine Adaption credentials and sufficient account access/credits exist, run the real estimate → explicit confirmation → status → download journey and record actual results. If credentials are unavailable, verify all non-credential paths and mark the live run blocked/unverified.

Do not invent test outcomes if browser automation or an external service is unavailable. In that case, list exact manual verification steps and the evidence still needed.

## Task 3 — Security and privacy review

Inspect for:
- Missing/weak JWT verification, untrusted identity claims, session mistakes, or broken logout/session handling.
- Unauthorized resource access, cross-tenant queries, ID guessing, missing ownership checks and unsafe service-role/RLS assumptions.
- Secrets in source, frontend bundles, logs, README, fixtures, screenshots, commits, or generated downloads.
- Unbounded uploads, rows, text length, pagination, report generation, provider costs, polling and retries.
- CSV formula injection, HTML injection, unsafe file names/paths, temporary-file leaks, unsafe parser assumptions, and dangerous error details.
- Raw feedback or tokens unnecessarily stored/logged, overly permissive CORS, missing secure transport expectations, and weak production configuration.
- Database migration integrity, backup/recovery assumptions, indexes, and error/transaction handling.

Fix critical/high-risk issues before calling the service release-ready. Document any issue that cannot be fixed within scope; if it can compromise account isolation, secrets, or data integrity, mark the release blocked.

## Task 4 — Confirm deployment configuration and deploy

- First inspect the user's configured host and current deployment files. Do not assume a host, project ID, domain, credentials, or access.
- Verify current host requirements/limits from official sources before finalizing the chosen deployment path.
- Confirm `.env.example` lists placeholders only and that secret files are ignored.
- Configure production secrets through host-managed secret settings, never by writing real keys into repo files or frontend `VITE_` variables.
- Build the frontend, apply reviewed migrations through a deliberate step, start the backend on host-provided `PORT` bound to `0.0.0.0`, and verify static assets/API routing and health behavior.
- Do not run destructive database resets or migration commands against production without explicit approval and backup.
- If Codex has no credentials/permission to deploy, prepare the exact build/start/secret/migration steps and report deployment as blocked—not completed.

## Task 5 — Final service verification

After a successful deploy, record:
- Deployed URL and exact commit SHA, if available.
- Migration status and deployment/start command used.
- Health check and authenticated API results.
- Actual tests and end-to-end scenarios completed.
- Live Gemini/Adaption integration status based on real calls only.
- Remaining defects, limitations, and unverified paths.

Update `README.md`, `docs/CURRENT_STATE_AUDIT.md`, and `docs/DEPLOYMENT.md` to reflect the real state. Do not leave future/planned functionality described as live. Distinguish **implemented and verified**, **implemented but unverified**, and **planned**. Never publish secrets, customer content, tokens, or provider data in the report.

## Release decision

Use one of these clear outcomes:

- **Ready for public beta:** required build/tests pass; no critical/high security or data-isolation issue remains; core workflow is verified on the deployment; remaining known limitations are explicit.
- **Not ready — fix required:** a critical workflow, authorization boundary, data integrity path, or deployment check fails.
- **Partially verified — external blocker:** the app works in the tested scope but credentials, host access, account credits, or unavailable tooling prevent specific external checks. List those checks exactly; do not imply full verification.

Do not commit/push. The user will review and push the final code. End with an honest release checklist and a suggested commit message appropriate to the actual changes.

Suggested commit message: `chore: harden and prepare SignalIQ public beta`
