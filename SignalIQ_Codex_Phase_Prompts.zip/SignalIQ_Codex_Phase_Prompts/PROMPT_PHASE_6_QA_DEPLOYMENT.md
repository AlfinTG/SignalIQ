# CODEX MASTER PROMPT — PHASE 6: FULL QA, SECURITY HARDENING & PUBLIC-BETA DEPLOYMENT

This is the final verification and release phase for SignalIQ. Unlike earlier phases, now perform the comprehensive test, security, integration, and deployment checks. Do not describe the product as released or fully functional until the applicable checks have actually passed.

## Read first

Read `AGENTS.md`, `README.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/DEVELOPMENT_PHASES.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md`, `docs/AI_AND_ADAPTION.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md`, and `docs/CURRENT_STATE_AUDIT.md`. Inspect the complete codebase, test scripts, migrations, environment examples, CI/deployment files and actual Git diff/branch. Use current official provider documentation for any deployment/auth/API detail that may have changed.

## Task 1 — Run the full project quality suite

Inspect package scripts and backend setup; run the real configured commands, including where available:

```bash
npm --prefix frontend run typecheck
npm --prefix frontend test
npm --prefix frontend run build
```

Run backend tests from the correct environment, for example on Windows:

```powershell
.\.venv\Scripts\python.exe -m pytest
```

or the actual configured equivalent. Also run the migration checks, formatting/lint commands if present, and any configured end-to-end/browser checks. Do not assume commands, test files, or dependencies exist; inspect first.

- Record exact commands, exit codes, and meaningful failure summaries.
- Fix bugs caused by implementation where feasible, and rerun failed checks.
- Don't suppress/skip tests just to get a green result. Report environment blockers plainly.
- Ensure automated tests do not require live provider credentials; live tests should be explicit/manual or separately marked.

## Task 2 — Verify end-to-end product scenarios

Use the available integration/browser tooling or a deployment-equivalent environment to exercise:

1. Sign up a new account and verify its private workspace initializes once.
2. Sign in/out, refresh the session, and handle expiration/invalid tokens.
3. Import a CSV with valid and invalid rows; verify preview, mapping, counts, and persistence.
4. Add/edit/delete a feedback record; verify the owner and changes are correct after refresh.
5. Run analysis with configured Gemini or choose an explicitly labeled demo path; verify results/provenance are stored correctly.
6. Exercise missing-key, provider timeout/rate-limit, malformed response, partial result, and retry paths without fabricated classifications or data loss.
7. Filter feedback and verify KPIs, chart values, issue groups, priorities, and reports agree on the same scope.
8. Open a prioritized issue and inspect evidence; update status; refresh and verify persistence on dashboard, issue list, and report.
9. Generate/download reports and CSV. Inspect formula-injection protection and HTML escaping.
10. Create a second account and attempt to access account A's feedback, issues, analyses, reports, and Adaption jobs through both UI and direct API/resource IDs. Every unauthorized attempt must fail without leaking data.
11. Restart the backend and verify persistent records, migrations, issue status, and Adaption job metadata are preserved.
12. Verify the responsive interface on approximately 390px mobile and 1366px desktop; ensure navigation, import dialogs, filters, charts, tables, and important actions remain usable.
13. If genuine Adaption credentials and sufficient account access/credits exist, run the real estimate → explicit confirmation → status → download journey and record actual results. If credentials are unavailable, verify all non-credential paths and mark the live run blocked/unverified.

Do not invent test outcomes if browser automation or an external service is unavailable. In that case, list exact manual verification steps and the evidence still needed.

## Task 3 — Security and privacy review

Inspect for:
- Missing/weak JWT verification, untrusted identity claims, session mistakes, or broken logout/session handling.
- Unauthorized resource access, cross-tenant queries, ID guessing, missing ownership checks and unsafe service-role/RLS assumptions.
- Secrets in source, frontend bundles, logs, README, fixtures, screenshots, commits, or generated downloads.
- Unbounded uploads, rows, text length, pagination, report generation, provider costs, polling and retries.
- CSV formula injection, HTML injection, unsafe file names/paths, temporary-file leaks, unsafe parser assumptions, and dangerous error details.
- Raw feedback or tokens unnecessarily stored/logged, overly permissive CORS, missing secure transport expectations, and weak production configuration.
- Database migration integrity, backup/recovery assumptions, indexes, and error/transaction handling.

Fix critical/high-risk issues before calling the service release-ready. Document any issue that cannot be fixed within scope; if it can compromise account isolation, secrets, or data integrity, mark the release blocked.

## Task 4 — Confirm deployment configuration and deploy

- First inspect the user's configured host and current deployment files. Do not assume a host, project ID, domain, credentials, or access.
- Verify current host requirements/limits from official sources before finalizing the chosen deployment path.
- Confirm `.env.example` lists placeholders only and that secret files are ignored.
- Configure production secrets through host-managed secret settings, never by writing real keys into repo files or frontend `VITE_` variables.
- Build the frontend, apply reviewed migrations through a deliberate step, start the backend on host-provided `PORT` bound to `0.0.0.0`, and verify static assets/API routing and health behavior.
- Do not run destructive database resets or migration commands against production without explicit approval and backup.
- If Codex has no credentials/permission to deploy, prepare the exact build/start/secret/migration steps and report deployment as blocked—not completed.

## Task 5 — Final service verification

After a successful deploy, record:
- Deployed URL and exact commit SHA, if available.
- Migration status and deployment/start command used.
- Health check and authenticated API results.
- Actual tests and end-to-end scenarios completed.
- Live Gemini/Adaption integration status based on real calls only.
- Remaining defects, limitations, and unverified paths.

Update `README.md`, `docs/CURRENT_STATE_AUDIT.md`, and `docs/DEPLOYMENT.md` to reflect the real state. Do not leave future/planned functionality described as live. Distinguish **implemented and verified**, **implemented but unverified**, and **planned**. Never publish secrets, customer content, tokens, or provider data in the report.

## Release decision

Use one of these clear outcomes:

- **Ready for public beta:** required build/tests pass; no critical/high security or data-isolation issue remains; core workflow is verified on the deployment; remaining known limitations are explicit.
- **Not ready — fix required:** a critical workflow, authorization boundary, data integrity path, or deployment check fails.
- **Partially verified — external blocker:** the app works in the tested scope but credentials, host access, account credits, or unavailable tooling prevent specific external checks. List those checks exactly; do not imply full verification.

Do not commit/push. The user will review and push the final code. End with an honest release checklist and a suggested commit message appropriate to the actual changes.

Suggested commit message: `chore: harden and prepare SignalIQ public beta`
