# CODEX MASTER PROMPT — PHASE 2: FRONTEND & UI/UX RECONSTRUCTION

You are rebuilding the frontend of **SignalIQ** within the existing repository. This phase implements the approved product experience—not another throwaway prototype. Work only on the frontend and its documented API/data-access boundary; the persistent backend is the next phase.

## Product and source of truth

Product: SignalIQ — “Find the signal. Fix the problem.”  
Goal: connect customer feedback to traceable insights, explainable priorities, actions, and reports.  
Visual direction: warm editorial analytics; warm ivory/stone, charcoal, muted natural greens, restrained terracotta/amber. Do not reintroduce the previous dominant navy/blue aesthetic.

Read `AGENTS.md`, `docs/CURRENT_STATE_AUDIT.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/UX_DESIGN_SPEC.md`, `docs/DESIGN_SYSTEM.md`, `docs/ARCHITECTURE.md`, and `docs/API_CONTRACTS.md`. Inspect existing source and tests before replacing anything. Reuse useful logic and dependencies where sensible; do not blindly delete all components.

## Scope of this phase

Reconstruct the React + TypeScript + Vite + Tailwind frontend, route hierarchy, design tokens, shared components, screen layouts, interactions, data-access abstractions, and user-facing states. Create public/auth route shells and authenticated workspace screens. Backend calls that do not exist yet must be represented through a typed API contract and a clearly isolated development fixture/adapter—not scattered hardcoded mock data.

Do not build the complete authentication/database backend here. Do not claim sign-up, real persistence, Gemini, or Adaption works unless those routes are already present and verified. Prepare the frontend to connect to Phase 3+ APIs without a rewrite.

## Task 1 — Establish a maintainable frontend structure

- Preserve the current project tooling and dependencies unless a concrete limitation is documented.
- Define clear boundaries among routes/pages, reusable UI components, domain types, API client, data mapping, derived metrics, and demo fixtures.
- Use strict TypeScript; avoid `any`, repeated business logic in UI components, and giant single-file page components.
- Centralize design tokens and shared layout rules. Avoid duplicate hardcoded color/spacing styles across pages.
- Keep API types aligned to `docs/API_CONTRACTS.md`; where contracts need a specific adjustment, update both the canonical doc and implementation consistently.
- Build environment-aware API URL configuration without embedding secrets in frontend environment values.

## Task 2 — Implement the application shell and routes

Create a cohesive responsive shell with:
- SignalIQ branding and consistent page titles/descriptions.
- Appropriate authenticated navigation for Overview, Feedback, Insights, Priorities & Actions, Reports, Data Quality & Adaptation, and Settings.
- Clear sign-in/sign-up/recovery entry states.
- A mobile navigation pattern that works with keyboard and touch.
- Context-appropriate page actions; no placeholder buttons.
- Account/workspace/loading/session-expired/error presentation based on the actual available data/session interface.

Route guards may use an explicit auth abstraction placeholder until Phase 3 completes, but do not pretend it is secure authentication. Make the boundary obvious in code and UI states so Phase 3 can replace it cleanly.

## Task 3 — Build all primary screens according to `UX_DESIGN_SPEC.md`

### Overview
- Display KPIs, sentiment mix, trend visualization, top issues, and a priority/action queue.
- Derive all data from the current fixture or API response; never hardcode KPI values as product logic.
- Show date range and filter scope consistently. Every chart/list/KPI that should respond to filters must share the same filtering contract.
- Provide honest first-run, no-data, filtered-empty, loading, and error states.

### Feedback Explorer
- Implement search, sorting, filters, page size/pagination or a scalable list pattern, row detail, add/edit/delete interactions, and CSV import UI.
- CSV flow: choose file, detect candidate columns, preview records, let user correct ambiguous mappings, validate rows, show accepted/rejected counts with reasons, and confirm import.
- Do not silently discard invalid rows or claim persistence where it is not implemented.
- Properly handle quotes, commas, Unicode, blank rows, bad dates/ratings, duplicate imports, long text, and formula-like spreadsheet values in exports.

### Insights
- Show coherent issue/theme summaries, time coverage, sentiment, severity signal, confidence/provenance, supporting feedback, and evidence navigation.
- Clearly differentiate real AI, demo/rules-based, unclassified, and not-yet-reviewed records.

### Priorities & Actions
- Show issue ranking with a plain-language score breakdown and the current weights from `docs/DECISIONS.md`.
- Show source comments supporting each issue and an action recommendation tied to evidence.
- Implement status controls for `Open`, `In progress`, and `Resolved` through the data-access abstraction.
- Don't label a local-only state as saved to the account/server. Use a visibly local development adapter until persistent APIs arrive.

### Reports
- Provide scope/date controls, preview, accurate metric labels, and a download action through a typed export utility.
- Report data must be derived from the selected dataset and filters; do not invent chart data or counts.

### Data Quality & Adaptation
- Provide label review/correction and verified-example selection UI according to `AI_AND_ADAPTION.md`.
- Display whether the provider is configured only when the backend health/config API supplies that information.
- Prepare an explicit estimate → confirmation → run → status → download UI. Do not automatically start a run. Do not claim an external run succeeded.

### Settings and account surfaces
- Show only settings supported by the product scope. Do not add billing or team invitation screens.

## Task 4 — Visual execution bar

- Inspect original repository references directly and use the findings documented during Phase 1.
- Apply the approved tokens consistently across all views.
- Use distinct page compositions and appropriate density, not identical grids of rounded white cards everywhere.
- Charts require meaningful axes/labels, responsive sizing, and empty states.
- Use accessible semantic HTML, visible focus, form labels, keyboard-safe dialogs, and sufficient contrast.
- Support approximately 390px mobile and 1366px desktop layouts. Prevent accidental page-wide horizontal overflow.
- Use realistic synthetic data only in clearly marked fixtures. Keep fixtures separate from production-facing API behavior.
- Never add people/avatars or decorative AI imagery where not useful to this analytical product.

## Task 5 — Integration readiness

- Implement a typed API client with clear response/error parsing and consistent loading/error behavior.
- Separate frontend-only derived calculations from server-owned persisted state.
- Add explicit adapter boundaries for auth/session, feedback CRUD/import, analysis runs, issue state, reports, and Adaption jobs.
- Use the planned API contracts and don't assume endpoints exist. If a route is unimplemented, represent it as a truthful unavailable state in development, not a fake success.
- Make the later switch to real APIs a targeted adapter implementation, not a rewrite of every page.

## Out of scope

- No database/auth backend implementation in this phase.
- No real review platform ingestion or billing.
- No invented live provider result.
- No large unrelated dependency upgrades or wholesale repository replacement.

## Completion

Use the available scripts to run a focused frontend typecheck/build or targeted checks only as practical; the comprehensive regression suite is reserved for Phase 6. Do not claim a check passed unless it ran. Fix obvious implementation-caused blockers before handing off, especially missing routes/imports and TypeScript errors.

Inspect the diff and report: screens implemented, controls wired, API placeholders/boundaries, responsive observations, known limitations, checks actually run, and suggested next phase. Do not commit or push; the user will do so.

Suggested commit message: `feat: reconstruct SignalIQ frontend experience`
