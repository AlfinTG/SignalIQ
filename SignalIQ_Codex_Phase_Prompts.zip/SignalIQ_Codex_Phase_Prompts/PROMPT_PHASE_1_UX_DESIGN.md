# CODEX MASTER PROMPT — PHASE 1: UX ARCHITECTURE & DESIGN LOCK

You are working inside the existing **SignalIQ** repository. This is Phase 1 of a phased reconstruction. Read this prompt fully and obey the canonical project docs. Do not implement the entire app in this phase.

## Product context

SignalIQ — “Find the signal. Fix the problem.” — turns customer feedback into traceable insights, explainable priorities, tracked actions, and reports. The target is a usable public-beta service, not a generic AI dashboard or a rushed demo.

## Read first

Read `AGENTS.md`, `README.md`, `docs/CURRENT_STATE_AUDIT.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/DEVELOPMENT_PHASES.md`, `docs/UX_DESIGN_SPEC.md`, and `docs/DESIGN_SYSTEM.md`. Also inspect the existing frontend structure and all original image assets in `images/` directly.

## Approved creative direction

Use **warm editorial analytics**: warm ivory and stone surfaces, charcoal typography, forest/sage green for the core positive/action accent, restrained terracotta or amber for selected attention states, soft neutral dividers, intentional whitespace, and distinctive information hierarchy. Avoid a dominant navy/blue sidebar, the familiar all-white/blue AI-generated dashboard aesthetic, excessive rounded cards, decorative gradients, oversized headings, unnecessary glow/shadows, and generic dashboard repetition.

The user has already approved this direction. Do not pause just to ask which color family they prefer. Make sensible, consistent design choices under the documented constraints. Do not alter the product brand from SignalIQ.

## Task 1 — Inspect and interpret the reference screenshots

- Open the actual images in `images/`; assess each at readable size.
- Identify useful information-architecture and interaction patterns, not merely their color palette.
- Separate “reference inspiration” from “elements to change.”
- Record the observations in `docs/UX_DESIGN_SPEC.md`; do not claim pixel-specific observations you did not make.

## Task 2 — Lock the complete product UX

Specify the screen inventory, hierarchy, user goals, navigation model, primary/secondary actions, empty/loading/success/partial-success/error states, keyboard/focus behavior, responsive behavior, and key transitions for:

1. Public product/entry route and sign-up/sign-in/recovery flows.
2. First-use onboarding and a clearly labeled synthetic sample dataset option.
3. Overview dashboard: KPIs, sentiment and trend views, recurring issues, priority queue, evidence, and contextual next action.
4. Feedback Explorer: source data, search, sort, filters, row details, add/edit/delete, CSV preview/mapping/validation/import progress and rejected-row reporting.
5. Insights: theme/issue summaries with evidence links, date coverage, confidence/provenance, and filter-aware analysis.
6. Priorities & Actions: score explanation, volume, negative share, severity/trend availability, supporting comments, recommendation, status lifecycle (`Open`, `In progress`, `Resolved`), and persisted changes.
7. Reports: report scope, date range, metric definitions, evidence coverage, and CSV/HTML or other documented downloadable formats.
8. Data Quality & Adaptation: review/correct labels, mark an example verified, choose eligible examples, preview/export data, request an Adaption estimate, explicit confirmation before running, actual provider status, errors, and available output download.
9. Settings: account/session state and workspace/account options in scope for v1. Do not add billing or team management.

For each screen document: purpose, target user question, layout regions, hierarchy, important content, control behaviors, data dependency, mobile adaptation, and failure/empty state. Make sure no page is included in navigation unless its planned or implemented behavior is specified.

## Task 3 — Make the design system actionable

Update `docs/DESIGN_SYSTEM.md` with usable semantic tokens and rules, including:
- Canvas, surface, elevated surface, text, muted text, border, primary/action, positive, warning, and destructive tokens.
- Typography roles, type scale, line lengths, density, spacing rhythm, sizing and responsive breakpoints.
- Buttons, inputs, selects, tables, filter chips, navigation, KPI blocks, chart framing, issue rows, dialogs, banners/toasts, badges, skeletons, and empty/error states.
- Focus-visible and keyboard-accessibility requirements.
- Rules for color contrast and never using color alone to encode sentiment/severity/status.
- Desktop, tablet, and mobile behavior, including readable data tables and usable filters.

Use restrained color, but don't force every element into a card. Prefer varied but consistent layouts and allow important data to have room.

## Task 4 — Define interaction and component contracts

- Provide a shared component inventory with responsibilities and variants.
- Decide which interactions belong to links/routes, dialogs, inline editors, filters, or server actions.
- Every visible control must do something real, be explicitly disabled with an explanation, or be removed.
- Charts and KPIs must eventually use current data and the active filter set. Do not prescribe hardcoded live-looking numbers.
- Clarify loading and asynchronous feedback for long AI/Adaption tasks.
- Specify an evidence pattern so each insight or recommended action can be traced to actual comments.

## Task 5 — Deliver a concrete implementation blueprint

- Update `docs/UX_DESIGN_SPEC.md` and `docs/DESIGN_SYSTEM.md`.
- If needed, append a numbered decision to `docs/DECISIONS.md` for a material new product/design decision; do not overwrite older history.
- Produce a prioritized screen/component implementation map for Phase 2.
- If the repository already has an accepted UI preview mechanism, you may create a minimal design preview, but do not perform broad page reconstruction here or introduce a new design framework solely for the preview.

## Constraints

- Do not change backend architecture or schema in this phase.
- Do not introduce dependencies without a clear need.
- Do not replace the supplied screenshots with generated assets or generic UI inspiration.
- Do not change product scope, branding, or documented non-goals.
- Do not stop for routine clarification; use the documented decisions and note genuine unresolved blockers.

## Focused checks and handoff

This is primarily a design/specification phase, so do not run a full application regression suite. Check markdown consistency/links if tooling exists, inspect the final diff, and verify all documented screens map to PRD requirements.

Report the files changed, design decisions locked, screenshot observations, any contradictions found, and how the Phase 2 implementation will follow the approved design. Do not commit/push; the user will do so.

Suggested commit message: `docs: lock SignalIQ UX and visual system`
