# CODEX MASTER PROMPT — PHASE 3: AUTHENTICATION, DATABASE & PERSISTENT API

Implement SignalIQ's persistent, multi-user service foundation in the existing repository. This is a backend/platform phase. Keep the approved frontend intact except for the minimum integration changes needed to connect real authentication and API data access.

## Product context and source of truth

SignalIQ is a public-beta customer feedback intelligence service. It must not use browser `localStorage` as the source of truth for signed-in user feedback or issue states. One account gets one private default workspace in v1; team collaboration and billing are out of scope.

Read `AGENTS.md`, `docs/DECISIONS.md`, `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API_CONTRACTS.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/DEPLOYMENT.md`, and the current audit. Inspect the existing FastAPI code, frontend auth/API adapter, environment handling, dependency files, tests, and deployment setup before implementation.

## Accepted architecture

- Keep FastAPI/Pydantic as the application API.
- Use Supabase Auth for identity and managed PostgreSQL for durable application data, as specified in `docs/DECISIONS.md`.
- Verify all SDK/auth/database integration details against current official Supabase documentation. Do not invent SDK functions or copy deprecated examples.
- Browser auth uses only the appropriate public/publishable configuration required by the current SDK. Privileged database credentials stay server-side.
- The frontend sends the authenticated access token to FastAPI. FastAPI must validate token signature/issuer/audience/expiry using the documented supported approach before trusting identity claims.
- Every database operation must be scoped to the authenticated user's private workspace. A browser-provided `user_id` or `workspace_id` is never proof of ownership.
- If the backend uses a privileged/service database credential that bypasses RLS, implement explicit server-side ownership checks on every operation and document this. RLS can be defense-in-depth, but do not falsely claim that RLS protects queries executed with a bypass role.
- Use repeatable version-controlled schema migrations. If a migration tool is not present, choose a minimal maintained tool compatible with this repository, document the choice, and use it consistently.

## Task 1 — Database schema and migrations

Implement the normalized schema in `docs/DATABASE.md` using migrations. At minimum support:

- User-owned private workspaces and the authenticated owner association.
- Feedback records, source/date/rating, analysis fields, analysis provenance/status, and timestamps.
- Issue state/tracking that is stable across refresh and server restarts.
- Analysis runs/batches and per-record outcome/provenance as needed for partial success/retries.
- Human-reviewed training examples or explicit verified-label state.
- Adaption application job metadata and its workspace/owner association, including dataset/run identifiers, current phase/status, row counts, estimates where returned, errors safe to persist, timestamps, and output readiness.
- Any report metadata only if the implemented requirements justify storing it; otherwise generate reports from authorized query results.

Add constraints, foreign keys, useful indexes, created/updated timestamps, and transaction behavior. Store dates consistently and document the timezone policy. Use durable metadata; do not store large sensitive source text in operational logs.

## Task 2 — Authentication and onboarding

- Implement sign-up, sign-in, sign-out, token/session refresh, and account recovery according to the current official Supabase-supported frontend flow.
- Add a safe first-user bootstrap: create or find that user's private default workspace idempotently. Avoid race-created duplicate default workspaces.
- Handle signed-out, expired-session, network/provider-error, and recovery states accessibly.
- Verify bearer tokens on the server for every private endpoint; do not trust a client-supplied email/user ID.
- Avoid logging access tokens or secrets.

## Task 3 — Persistent API

Implement or align the API endpoints in `docs/API_CONTRACTS.md` for:

- Health and non-sensitive application/provider readiness.
- Authorized feedback list/filter/pagination/detail/create/update/delete and CSV import where specified.
- Authorized issue state read/update.
- Analysis-run metadata and results needed by Phase 4.
- Verified training-example selection and Adaption job metadata needed by Phase 5.

For every private route:
- Establish the authenticated principal first.
- Resolve the private workspace server-side.
- Scope every select/update/delete to that workspace or owner.
- Verify a resource belongs to the workspace before returning or changing it.
- Return consistent error shapes and appropriate HTTP status codes.
- Bound pagination, row count, text size, import size, and other user-controlled costs.
- Do not expose database internals, secrets, token claims unrelated to the UI, or stack traces.

Do not create generic overpowered CRUD endpoints that bypass domain checks. Prevent cross-account access to records by guessing IDs.

## Task 4 — Frontend integration

Replace Phase 2 placeholder/local adapter behavior for auth and persistent feedback/issue state with a thin real API integration. Preserve the approved design and reusable component boundaries. Remove browser persistence as the authority for real account data. `localStorage` may be used only for harmless preferences or non-sensitive transient UX where documented—not as silent fallback storage for server failures.

If an existing local sample workspace exists, do not automatically upload it to a user account. Offer an explicit import/migration choice only if implemented and documented. Keep clearly labeled sample/demo data isolated from real records.

## Task 5 — Security and migration readiness

- Use environment variables for server secrets and update `.env.example` with placeholders only.
- Confirm `.env`, secrets, database exports, downloaded customer data, virtual environments, and build output follow `.gitignore` policy.
- Validate input types/limits and consistently normalize errors.
- Make migrations repeatable on a fresh database and safe for an upgrade path. Never run destructive data resets.
- Write/adjust authorization tests for allow and deny paths, including two separate accounts and attempts to access each other's resource IDs.
- Document database/auth setup and required secrets without adding real keys.

## Constraints and workflow

- Do not start Gemini redesign or implement the full Adaption workflow here; this phase provides the persistence/security foundation they will use.
- Do not add teams, billing, third-party feedback connectors, or complex organization roles.
- Check current official docs before settling on exact token verification, JWT/JWKS, client, and database-driver details.
- Do not ask routine questions. Use accepted decisions; if credentials are unavailable, implement the correct configuration/error path and clearly mark live verification as blocked.
- Do not claim public production readiness merely because auth code exists.

## Focused checks and handoff

Run only focused migration/auth/API checks practical in this phase; reserve broad end-to-end/full-suite validation for Phase 6. Never describe unrun tests as passed. Review all private routes for ownership enforcement before handoff.

Report schema/migrations, auth implementation, private endpoints, how identity and ownership are checked, checks actually run, missing service credentials, and unverified manual tasks. Do not commit/push; the user will do so.

Suggested commit message: `feat: add authenticated persistent SignalIQ service`
